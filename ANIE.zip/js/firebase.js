/* ============================================================
   ANIE Platform - Firebase Service Layer
   ============================================================ */

class FirebaseService {
  constructor() {
    this.db = null;
    this.auth = null;
    this.collectionRef = null;
    this.initialized = false;
    this.listeners = [];
  }

  /**
   * Initialize Firebase
   */
  init() {
    if (this.initialized) return;

    try {
      firebase.initializeApp(CONFIG.firebase);
      this.db = firebase.firestore();
      this.auth = firebase.auth();
      this.collectionRef = this.db.collection(CONFIG.app.collectionName);
      this.initialized = true;
      
      console.log('✅ Firebase initialized successfully');
    } catch (error) {
      console.error('❌ Firebase initialization failed:', error);
      throw error;
    }
  }

  /**
   * Auto-detect which collection has data.
   * Tries 'supervisors' first, falls back to 'مؤطرين' (old name).
   * Updates CONFIG.app.collectionName accordingly.
   * @returns {Promise<string>} The detected collection name
   */
  async detectCollection() {
    if (!this.initialized) this.init();

    const collectionsToTry = ['supervisors', 'مؤطرين'];
    
    for (const colName of collectionsToTry) {
      try {
        const snapshot = await this.db.collection(colName).limit(1).get();
        if (!snapshot.empty) {
          console.log(`📁 Detected collection: "${colName}" (has data)`);
          CONFIG.app.collectionName = colName;
          this.collectionRef = this.db.collection(colName);
          return colName;
        } else {
          console.log(`📁 Collection "${colName}" exists but is empty`);
        }
      } catch (err) {
        // Collection might not exist - try next one
        console.log(`📁 Collection "${colName}" not found or not accessible:`, err.message);
      }
    }

    // Fall back to default
    console.log(`📁 Using default collection: "${CONFIG.app.collectionName}"`);
    return CONFIG.app.collectionName;
  }

  /**
   * Get all entries with real-time listener
   * @param {Function} callback - Called with data snapshot
   * @returns {Function} Unsubscribe function
   */
  onEntriesChange(callback) {
    if (!this.initialized) this.init();

    const unsubscribe = this.collectionRef.onSnapshot(
      (snapshot) => {
        const data = {};
        snapshot.forEach(doc => {
          data[doc.id] = doc.data();
        });
        callback(data);
      },
      (error) => {
        console.error('Firestore listener error:', error);
        this._handleError(error);
      }
    );

    this.listeners.push(unsubscribe);
    return unsubscribe;
  }

  /**
   * Add a new entry
   * @param {Object} entry - Entry data
   * @returns {Promise<string>} Document ID
   */
  async addEntry(entry) {
    if (!this.initialized) this.init();

    const docRef = await this.collectionRef.add({
      ...entry,
      createdAt: Date.now(),
      updatedAt: Date.now()
    });

    return docRef.id;
  }

  /**
   * Update an entry
   * @param {string} id - Document ID
   * @param {Object} updates - Fields to update
   * @returns {Promise<void>}
   */
  async updateEntry(id, updates) {
    if (!this.initialized) this.init();

    await this.collectionRef.doc(id).update({
      ...updates,
      updatedAt: Date.now()
    });
  }

  /**
   * Delete an entry
   * @param {string} id - Document ID
   * @returns {Promise<void>}
   */
  async deleteEntry(id) {
    if (!this.initialized) this.init();

    await this.collectionRef.doc(id).delete();
  }

  /**
   * Get a single entry
   * @param {string} id - Document ID
   * @returns {Promise<Object|null>}
   */
  async getEntry(id) {
    if (!this.initialized) this.init();

    const doc = await this.collectionRef.doc(id).get();
    return doc.exists ? { id: doc.id, ...doc.data() } : null;
  }

  /**
   * Query entries with filters
   * @param {Object} filters - Query filters
   * @returns {Promise<Array>}
   */
  async queryEntries(filters = {}) {
    if (!this.initialized) this.init();

    let query = this.collectionRef;

    if (filters.center) {
      query = query.where('center', '==', filters.center);
    }
    if (filters.assignLevel) {
      query = query.where('assignLevel', '==', filters.assignLevel);
    }
    if (filters.flagged !== undefined) {
      query = query.where('flagged', '==', filters.flagged);
    }

    const snapshot = await query.get();
    const results = [];
    snapshot.forEach(doc => {
      results.push({ id: doc.id, ...doc.data() });
    });

    return results;
  }

  /**
   * Get connection status
   * @returns {Promise<boolean>}
   */
  async checkConnection() {
    if (!this.initialized) this.init();

    try {
      await this.collectionRef.limit(1).get();
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Handle errors
   */
  _handleError(error) {
    const errorBanner = document.getElementById('errorBanner');
    if (errorBanner) {
      errorBanner.style.display = 'block';
      
      // Check for specific permission errors
      const message = error.message || '';
      if (message.includes('Missing or insufficient permissions') || message.includes('permission_denied')) {
        errorBanner.textContent = `⚠️ خطأ في صلاحيات قاعدة البيانات: يرجى نشر قواعد Firestore أولاً.
        
الرجاء اتباع الخطوات التالية:
1. اذهب إلى: https://console.firebase.google.com/project/inti5ab/firestore/rules
2. انسخ محتوى ملف firestore.rules
3. الصقه وانقر "Publish"
4. قم بتحديث الصفحة`;
      } else {
        errorBanner.textContent = `⚠️ خطأ في قاعدة البيانات: ${message}`;
      }
    }
  }

  // ============================================================
  // Centers Management (CRUD)
  // ============================================================

  /**
   * Get all centers with real-time listener
   * @param {Function} callback - Called with centers data
   * @returns {Function} Unsubscribe function
   */
  onCentersChange(callback) {
    if (!this.initialized) this.init();

    const unsubscribe = this.db.collection('centers').onSnapshot(
      (snapshot) => {
        const data = {};
        snapshot.forEach(doc => {
          data[doc.id] = doc.data();
        });
        callback(data);
      },
      (error) => {
        console.error('Centers listener error:', error);
      }
    );

    this.listeners.push(unsubscribe);
    return unsubscribe;
  }

  /**
   * Add a new center
   * @param {Object} center - { name, offices: number[] }
   * @returns {Promise<string>} Document ID
   */
  async addCenter(center) {
    if (!this.initialized) this.init();

    const docRef = await this.db.collection('centers').add({
      name: center.name,
      offices: center.offices || [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    });

    return docRef.id;
  }

  /**
   * Update or create a center
   * @param {string} id - Document ID
   * @param {Object} updates - { name?, offices? }
   * @returns {Promise<void>}
   */
  async updateCenter(id, updates) {
    if (!this.initialized) this.init();

    // Use set() with merge: true so it works for both new AND existing documents
    await this.db.collection('centers').doc(id).set({
      ...updates,
      updatedAt: Date.now()
    }, { merge: true });
  }

  /**
   * Delete a center
   * @param {string} id - Document ID
   * @returns {Promise<void>}
   */
  async deleteCenter(id) {
    if (!this.initialized) this.init();

    await this.db.collection('centers').doc(id).delete();
  }

  /**
   * Get all centers once (without listener)
   * @returns {Promise<Object>} Centers data
   */
  async getCenters() {
    if (!this.initialized) this.init();

    const snapshot = await this.db.collection('centers').get();
    const data = {};
    snapshot.forEach(doc => {
      data[doc.id] = doc.data();
    });
    return data;
  }

  /**
   * Seed default centers if none exist
   * @returns {Promise<void>}
   */
  async seedDefaultCenters() {
    if (!this.initialized) this.init();

    const snapshot = await this.db.collection('centers').limit(1).get();
    if (!snapshot.empty) return; // Centers already exist

    const defaults = {
      "01": { name: "متقنة عمر إدريس", offices: [1, 2, 3, 4, 11, 12, 24, 30, 31, 38] },
      "02": { name: "مريقي محمد", offices: [5, 6, 7, 8, 13, 14, 25, 32, 39] },
      "03": { name: "طنجاوي الحاج", offices: [15, 16, 17, 18, 19, 26, 27, 33, 34, 40] },
      "04": { name: "قديم عطالله", offices: [20, 21, 22, 23, 28, 29, 35, 36, 37] },
      "05": { name: "شوشة السايح", offices: [9, 10] }
    };

    const batch = this.db.batch();
    Object.entries(defaults).forEach(([code, center]) => {
      const docRef = this.db.collection('centers').doc(code);
      batch.set(docRef, {
        name: center.name,
        offices: center.offices,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    });
    await batch.commit();
    console.log('✅ Default centers seeded successfully');
  }

  /**
   * Clean up listeners
   */
  destroy() {
    this.listeners.forEach(unsubscribe => unsubscribe());
    this.listeners = [];
  }
}

// Export singleton instance
const firebaseService = new FirebaseService();
