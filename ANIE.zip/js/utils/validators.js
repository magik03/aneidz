/* ============================================================
   ANIE Platform - Validation Utilities
   ============================================================ */

const Validators = {
  /**
   * Validate required field
   */
  required(value, fieldName) {
    if (!value || (typeof value === 'string' && !value.trim())) {
      return `حقل "${fieldName}" مطلوب`;
    }
    return null;
  },

  /**
   * Validate full name (Arabic/English letters, spaces, dashes)
   */
  name(name, fieldName = 'الاسم') {
    if (!name || !name.trim()) return `حقل "${fieldName}" مطلوب`;
    if (name.trim().length < 2) return `${fieldName} يجب أن يكون 2 أحرف على الأقل`;
    if (name.trim().length > 50) return `${fieldName} يجب أن لا يتجاوز 50 حرفاً`;
    return null;
  },

  /**
   * Validate phone number (Algerian format)
   */
  phone(phone) {
    if (!phone || !phone.trim()) return null; // Optional
    const cleaned = phone.replace(/[\s\-\(\)]/g, '');
    if (!/^(0[56789]\d{8})$/.test(cleaned)) {
      return 'رقم الهاتف غير صحيح (مثال: 0555123456)';
    }
    return null;
  },

  /**
   * Validate electoral number
   */
  electoralNum(num) {
    if (!num || !num.trim()) return null; // Optional
    if (!/^\d{6,10}$/.test(num.trim())) {
      return 'الرقم الانتخابي يجب أن يكون بين 6 و 10 أرقام';
    }
    return null;
  },

  /**
   * Validate date of birth
   */
  birthDate(date) {
    if (!date) return 'تاريخ الميلاد مطلوب';
    
    const parts = date.split('-');
    if (parts.length !== 3) return 'تاريخ الميلاد غير صحيح';
    
    const year = parseInt(parts[0]);
    const month = parseInt(parts[1]);
    const day = parseInt(parts[2]);
    
    if (year < 1920 || year > new Date().getFullYear()) {
      return 'سنة الميلاد غير صحيحة';
    }
    if (month < 1 || month > 12) return 'شهر الميلاد غير صحيح';
    if (day < 1 || day > 31) return 'يوم الميلاد غير صحيح';
    
    return null;
  },

  /**
   * Validate education level
   */
  educationLevel(level) {
    if (!level) return 'المستوى التعليمي مطلوب';
    if (!CONFIG.EDUCATION_LEVELS.includes(level)) {
      return 'المستوى التعليمي غير صحيح';
    }
    return null;
  },

  /**
   * Validate email format
   */
  email(email) {
    if (!email || !email.trim()) return 'البريد الإلكتروني مطلوب';
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!re.test(email.trim())) {
      return 'البريد الإلكتروني غير صحيح';
    }
    return null;
  },

  /**
   * Validate password strength
   * @returns {Object} { valid: boolean, message: string, strength: string }
   */
  password(password) {
    if (!password) return { valid: false, message: 'كلمة المرور مطلوبة', strength: 'none' };
    
    const result = { valid: true, message: '', strength: 'weak' };
    
    if (password.length < 6) {
      result.valid = false;
      result.message = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
      result.strength = 'weak';
      return result;
    }
    
    let score = 0;
    
    // Length check
    if (password.length >= 8) score += 1;
    if (password.length >= 12) score += 1;
    
    // Character variety
    if (/[a-z]/.test(password)) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^a-zA-Z0-9]/.test(password)) score += 1;
    
    if (score <= 2) {
      result.strength = 'weak';
      result.message = 'كلمة مرور ضعيفة';
    } else if (score <= 4) {
      result.strength = 'medium';
      result.message = 'كلمة مرور متوسطة';
    } else {
      result.strength = 'strong';
      result.message = 'كلمة مرور قوية';
    }
    
    result.valid = score >= 3;
    return result;
  },

  /**
   * Validate passwords match
   */
  passwordMatch(password, confirmPassword) {
    if (password !== confirmPassword) {
      return 'كلمة المرور غير متطابقة';
    }
    return null;
  },

  /**
   * Validate center selection
   */
  center(centerCode) {
    if (!centerCode) return 'المركز مطلوب';
    if (!CONFIG.CENTERS[centerCode]) return 'المركز غير صحيح';
    return null;
  },

  /**
   * Validate office number
   */
  officeNumber(officeNumber, centerCode) {
    if (!officeNumber) return 'رقم المكتب مطلوب';
    if (centerCode && CONFIG.CENTERS[centerCode]) {
      const offices = CONFIG.CENTERS[centerCode].offices;
      if (!offices.includes(parseInt(officeNumber))) {
        return 'رقم المكتب غير صحيح لهذا المركز';
      }
    }
    return null;
  },

  /**
   * Validate position selection
   */
  position(position, level) {
    if (!position) return 'المنصب مطلوب';
    
    const allPositions = CONFIG.ALL_POSITIONS;
    if (!allPositions.includes(position)) {
      return 'المنصب غير صحيح';
    }
    
    if (level === 'center' && !CONFIG.CENTER_POSITIONS.includes(position)) {
      return 'هذا المنصب غير متاح على مستوى المركز';
    }
    
    if (level === 'office' && !CONFIG.POSITIONS_ORDER.includes(position)) {
      return 'هذا المنصب غير متاح على مستوى المكتب';
    }
    
    return null;
  },

  /**
   * Validate notes length
   */
  notes(notes) {
    if (notes && notes.length > 500) {
      return 'الملاحظات يجب أن لا تتجاوز 500 حرف';
    }
    return null;
  },

  /**
   * Validate entire registration form
   * @returns {Object} { valid: boolean, errors: Object }
   */
  validateRegistrationForm(data) {
    const errors = {};
    
    const nameErr = this.name(data.name, 'الاسم');
    if (nameErr) errors.name = nameErr;
    
    const lastNameErr = this.name(data.lastName, 'اللقب');
    if (lastNameErr) errors.lastName = lastNameErr;
    
    const birthErr = this.birthDate(data.birth);
    if (birthErr) errors.birth = birthErr;
    
    const phoneErr = this.phone(data.phone);
    if (phoneErr) errors.phone = phoneErr;
    
    const electoralErr = this.electoralNum(data.electoralNum);
    if (electoralErr) errors.electoralNum = electoralErr;
    
    const educationErr = this.educationLevel(data.educationLevel);
    if (educationErr) errors.educationLevel = educationErr;
    
    const notesErr = this.notes(data.notes);
    if (notesErr) errors.notes = notesErr;
    
    return {
      valid: Object.keys(errors).length === 0,
      errors
    };
  },

  /**
   * Validate distribution form
   */
  validateDistributionForm(data) {
    const errors = {};
    
    if (!data.moatirId) errors.moatirId = 'يرجى اختيار المؤطر';
    
    const centerErr = this.center(data.center);
    if (centerErr) errors.center = centerErr;
    
    if (data.level === 'office') {
      const officeErr = this.officeNumber(data.officeNumber, data.center);
      if (officeErr) errors.officeNumber = officeErr;
      
      const posErr = this.position(data.officePosition, 'office');
      if (posErr) errors.officePosition = posErr;
      
      if (!data.officeType) errors.officeType = 'نوع المكتب مطلوب';
    } else {
      const posErr = this.position(data.centerPosition, 'center');
      if (posErr) errors.centerPosition = posErr;
    }
    
    return {
      valid: Object.keys(errors).length === 0,
      errors
    };
  },

  /**
   * Show validation errors on form fields
   */
  showFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    if (!field) return;
    
    field.classList.add('error');
    
    const errorEl = field.parentElement.querySelector('.input-error');
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.classList.add('show');
    }
  },

  /**
   * Clear validation errors
   */
  clearFieldErrors(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
    form.querySelectorAll('.input-error').forEach(el => {
      el.textContent = '';
      el.classList.remove('show');
    });
  }
};
