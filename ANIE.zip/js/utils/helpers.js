/* ============================================================
   ANIE Platform - Helper Functions
   ============================================================ */

const Helpers = {
  /**
   * Format date from YYYY-MM-DD to DD/MM/YYYY
   */
  formatDate(d) {
    if (!d) return '—';
    const parts = d.split('-');
    if (parts.length !== 3) return d;
    return parts[2] + '/' + parts[1] + '/' + parts[0];
  },

  /**
   * Escape HTML to prevent XSS
   */
  escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  },

  /**
   * Get center label (name) from code
   */
  centerLabel(code) {
    if (!code) return '';
    const c = CONFIG.CENTERS[code];
    return c ? `مركز ${c.name}` : `مركز ${code}`;
  },

  /**
   * Get entry position (office or center)
   */
  getEntryPosition(e) {
    if (!e) return null;
    if (e.assignLevel === 'center') return e.centerPosition || null;
    if (e.assignLevel === 'office') return e.officePosition || null;
    return null;
  },

  /**
   * Generate a unique ID
   */
  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  },

  /**
   * Debounce function for search
   */
  debounce(func, wait = 300) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /**
   * Throttle function
   */
  throttle(func, limit = 300) {
    let inThrottle;
    return function(...args) {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  /**
   * Save to localStorage
   */
  saveToStorage(key, value) {
    try {
      localStorage.setItem(`anie_${key}`, JSON.stringify(value));
    } catch (e) {
      console.warn('localStorage save failed:', e);
    }
  },

  /**
   * Load from localStorage
   */
  loadFromStorage(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(`anie_${key}`);
      return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
      console.warn('localStorage load failed:', e);
      return defaultValue;
    }
  },

  /**
   * Remove from localStorage
   */
  removeFromStorage(key) {
    try {
      localStorage.removeItem(`anie_${key}`);
    } catch (e) {
      console.warn('localStorage remove failed:', e);
    }
  },

  /**
   * Copy text to clipboard
   */
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      // Fallback
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      return true;
    }
  },

  /**
   * Check if device is mobile
   */
  isMobile() {
    return window.innerWidth <= 767;
  },

  /**
   * Check if device is tablet
   */
  isTablet() {
    return window.innerWidth > 767 && window.innerWidth <= 991;
  },

  /**
   * Format number with commas
   */
  formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  },

  /**
   * Get color for position
   */
  getPositionColor(position) {
    return CONFIG.POSITION_COLORS[position] || '#3d8bff';
  },

  /**
   * Sort entries by position then createdAt
   */
  sortEntries(entries) {
    const allPositions = CONFIG.ALL_POSITIONS;
    return entries.sort((a, b) => {
      const posA = allPositions.indexOf(this.getEntryPosition(a));
      const posB = allPositions.indexOf(this.getEntryPosition(b));
      if (posA !== posB) return posA - posB;
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
  },

  /**
   * Truncate text with ellipsis
   */
  truncate(str, length = 50) {
    if (!str) return '';
    if (str.length <= length) return str;
    return str.substring(0, length) + '...';
  },

  /**
   * Get today's date in YYYY-MM-DD format
   */
  getToday() {
    return new Date().toISOString().split('T')[0];
  },

  /**
   * Calculate age from birth date
   */
  calculateAge(birthDate) {
    if (!birthDate) return null;
    const parts = birthDate.split('-');
    const birth = new Date(parts[0], parts[1] - 1, parts[2]);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  }
};
