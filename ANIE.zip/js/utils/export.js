/* ============================================================
   ANIE Platform - Export Utilities (Excel & PDF)
   ============================================================ */

const ExportUtils = {
  /**
   * Build rows for Excel export
   */
  buildExportRows(allEntries, onlyAssigned = false) {
    const ids = Object.keys(allEntries).sort((a, b) => {
      const eA = allEntries[a], eB = allEntries[b];
      if ((eA.center || '') !== (eB.center || '')) 
        return (eA.center || '').localeCompare(eB.center || '');
      if (String(eA.officeNumber || '') !== String(eB.officeNumber || '')) 
        return String(eA.officeNumber || '').localeCompare(String(eB.officeNumber || ''));
      return CONFIG.ALL_POSITIONS.indexOf(Helpers.getEntryPosition(eA)) - 
             CONFIG.ALL_POSITIONS.indexOf(Helpers.getEntryPosition(eB));
    });

    const rows = [];
    ids.forEach(id => {
      const e = allEntries[id];
      if (onlyAssigned && !e.assignLevel) return;
      
      rows.push({
        'الاسم': e.name || '',
        'اللقب': e.lastName || '',
        'تاريخ الميلاد': e.birth ? Helpers.formatDate(e.birth) : '',
        'الرقم الانتخابي': e.electoralNum || '',
        'رقم الهاتف': e.phone || '',
        'المستوى التعليمي': e.educationLevel || '',
        'المنصب': Helpers.getEntryPosition(e) || '',
        'المركز': e.center ? `${e.center} - ${CONFIG.CENTERS[e.center]?.name || ''}` : '',
        'رقم المكتب': e.assignLevel === 'office' ? (e.officeNumber || '') : '',
        'نوع المكتب': e.assignLevel === 'office' ? (e.officeType || '') : '',
        'مستوى التوزيع': e.assignLevel === 'center' ? 'طاقم المركز' : (e.assignLevel === 'office' ? 'مكتب' : ''),
        'مُشار عليه': e.flagged ? 'نعم' : 'لا',
        'نوع المشكلة': e.issueType || '',
        'ملاحظات': e.notes || ''
      });
    });
    return rows;
  },

  /**
   * Export to Excel
   */
  exportToExcel(allEntries, onlyAssigned = false) {
    const rows = this.buildExportRows(allEntries, onlyAssigned);
    if (rows.length === 0) {
      toast.warning('لا توجد بيانات لتصديرها');
      return;
    }

    const ws = XLSX.utils.json_to_sheet(rows);
    ws['!cols'] = [
      { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 16 },
      { wch: 14 }, { wch: 14 }, { wch: 22 }, { wch: 26 },
      { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 12 },
      { wch: 20 }, { wch: 26 }
    ];

    // Style header
    const headerStyle = {
      font: { bold: true, color: { rgb: "FFFFFF" } },
      fill: { fgColor: { rgb: "3D8BFF" } },
      alignment: { horizontal: "center", vertical: "center" }
    };

    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1:N1');
    for (let C = range.s.c; C <= range.e.c; ++C) {
      const address = XLSX.utils.encode_cell({ r: 0, c: C });
      if (!ws[address]) continue;
      ws[address].s = headerStyle;
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'المؤطرين');
    
    const fileName = onlyAssigned ? 'المؤطرين_الموزعين.xlsx' : 'جميع_المؤطرين.xlsx';
    XLSX.writeFile(wb, fileName);
    
    toast.success(`تم تصدير ${rows.length} مؤطر بنجاح ✅`);
  },

  /**
   * Export to PDF with professional layout
   */
  async exportToPDF(allEntries, options = {}) {
    const { onlyAssigned = false, title = 'تقرير المؤطرين' } = options;
    const rows = this.buildExportRows(allEntries, onlyAssigned);
    
    if (rows.length === 0) {
      toast.warning('لا توجد بيانات لتصديرها');
      return;
    }

    // Dynamically load jsPDF if not available
    if (typeof window.jspdf === 'undefined') {
      await this._loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
      await this._loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.1/jspdf.plugin.autotable.min.js');
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('landscape', 'mm', 'a4');
    
    // Title
    doc.setFont('cairo', 'bold');
    doc.setFontSize(22);
    doc.setTextColor(61, 139, 255);
    doc.text(title, doc.internal.pageSize.width / 2, 20, { align: 'center' });
    
    // Subtitle
    doc.setFontSize(12);
    doc.setTextColor(142, 160, 189);
    const dateStr = new Date().toLocaleDateString('ar-DZ');
    doc.text(`تاريخ التقرير: ${dateStr} | إجمالي: ${rows.length} مؤطر`, 
      doc.internal.pageSize.width / 2, 30, { align: 'center' });

    // Table
    const tableData = rows.map(r => Object.values(r));
    const headers = Object.keys(rows[0]);
    
    doc.autoTable({
      head: [headers],
      body: tableData,
      startY: 35,
      styles: {
        font: 'cairo',
        fontSize: 8,
        cellPadding: 2,
        halign: 'right'
      },
      headStyles: {
        fillColor: [61, 139, 255],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        halign: 'center'
      },
      alternateRowStyles: {
        fillColor: [245, 247, 250]
      },
      didDrawPage: (data) => {
        // Footer
        doc.setFontSize(8);
        doc.setTextColor(142, 160, 189);
        doc.text(`الصفحة ${doc.internal.getNumberOfPages()}`, 
          doc.internal.pageSize.width / 2, 
          doc.internal.pageSize.height - 10, 
          { align: 'center' });
      }
    });

    // Footer line
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setDrawColor(61, 139, 255);
      doc.setLineWidth(0.5);
      doc.line(20, doc.internal.pageSize.height - 15, 
        doc.internal.pageSize.width - 20, doc.internal.pageSize.height - 15);
    }

    const fileName = onlyAssigned ? 'تقرير_المؤطرين_الموزعين.pdf' : 'تقرير_جميع_المؤطرين.pdf';
    doc.save(fileName);
    
    toast.success(`تم تصدير PDF بنجاح ✅`);
  },

  /**
   * Print directly with professional format
   */
  printReport(allEntries, onlyAssigned = false) {
    const rows = this.buildExportRows(allEntries, onlyAssigned);
    if (rows.length === 0) {
      toast.warning('لا توجد بيانات للطباعة');
      return;
    }

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('الرجاء السماح بالنوافق المنبثقة للطباعة');
      return;
    }

    const headers = Object.keys(rows[0]);
    const headerRow = headers.map(h => `<th>${h}</th>`).join('');
    
    const bodyRows = rows.map(row => {
      const cells = headers.map(h => `<td>${Helpers.escapeHtml(row[h] || '')}</td>`).join('');
      return `<tr>${cells}</tr>`;
    }).join('');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>تقرير المؤطرين</title>
        <style>
          @page { size: landscape; margin: 15mm; }
          * { box-sizing: border-box; }
          body {
            font-family: 'Cairo', 'Tahoma', sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
          }
          .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 3px solid #3d8bff;
          }
          .header h1 {
            color: #3d8bff;
            margin: 0 0 5px;
            font-size: 24px;
          }
          .header p {
            color: #666;
            margin: 0;
            font-size: 13px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
          }
          th {
            background: #3d8bff;
            color: #fff;
            padding: 8px 6px;
            text-align: center;
            font-weight: 700;
          }
          td {
            padding: 6px;
            border: 1px solid #ddd;
            text-align: center;
          }
          tr:nth-child(even) { background: #f8f9fa; }
          tr:hover { background: #e8f0fe; }
          .footer {
            text-align: center;
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #ddd;
            font-size: 11px;
            color: #666;
          }
          @media print {
            body { padding: 0; }
            .header { margin-bottom: 15px; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>🇩🇿 منصة تسجيل المؤطرين</h1>
          <p>${onlyAssigned ? 'تقرير المؤطرين الموزعين' : 'تقرير جميع المؤطرين'} | 
             التاريخ: ${new Date().toLocaleDateString('ar-DZ')} | 
             العدد الإجمالي: ${rows.length}</p>
        </div>
        <table>
          <thead><tr>${headerRow}</tr></thead>
          <tbody>${bodyRows}</tbody>
        </table>
        <div class="footer">
          تم إنشاء هذا التقرير بواسطة منصة تسجيل المؤطرين ANIE © ${new Date().getFullYear()}
        </div>
        <script>
          window.onload = function() {
            window.print();
            setTimeout(function() { window.close(); }, 1000);
          }
        <\/script>
      </body>
      </html>
    `);

    printWindow.document.close();
  },

  /**
   * Load external script dynamically
   */
  _loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }
};
