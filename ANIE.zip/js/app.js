/* ============================================================
   ANIE Platform - Main Application Bootstrap
   ============================================================ */

/**
 * Theme Manager - Handles dark/light mode
 */
class ThemeManager {
  constructor() {
    this.currentTheme = Helpers.loadFromStorage('theme', 'dark');
  }

  init() {
    this.applyTheme(this.currentTheme);
    this._setupToggle();
  }

  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    this.currentTheme = theme;
    Helpers.saveToStorage('theme', theme);

    const icon = document.getElementById('themeToggleIcon');
    if (icon) {
      icon.textContent = theme === 'dark' ? '☀️' : '🌙';
    }
  }

  toggle() {
    const newTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
    this.applyTheme(newTheme);
    toast.info(`تم التبديل إلى الوضع ${newTheme === 'dark' ? 'الدّاكن' : 'الفاتح'}`);
  }

  _setupToggle() {
    const btn = document.getElementById('btnThemeToggle');
    if (btn) {
      btn.addEventListener('click', () => this.toggle());
    }
  }
}

class ConnectionManager {
  constructor() {
    this.dot = document.getElementById('connDot');
    this.text = document.getElementById('connText');
    this.checkInterval = null;
  }

  init() {
    this._checkConnection();
    this.checkInterval = setInterval(() => this._checkConnection(), 30000);
  }

  async _checkConnection() {
    try {
      const connected = await firebaseService.checkConnection();
      if (this.dot) {
        this.dot.className = 'conn-dot ' + (connected ? 'on' : 'off');
      }
      if (this.text) {
        this.text.textContent = connected ? 'متصل بقاعدة البيانات (Firestore)' : 'غير متصل بقاعدة البيانات';
      }
    } catch (err) {
      if (this.dot) this.dot.className = 'conn-dot off';
      if (this.text) this.text.textContent = 'غير متصل: ' + err.message;
    }
  }

  destroy() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }
  }
}

class TabManager {
  constructor() {
    this.tabs = document.querySelectorAll('.tab-btn');
    this.sections = document.querySelectorAll('.tab-section');
  }

  init() {
    this.tabs.forEach(btn => {
      btn.addEventListener('click', () => this._switchTab(btn));
    });
  }

  _switchTab(btn) {
    this.tabs.forEach(b => b.classList.remove('active'));
    this.sections.forEach(s => s.classList.remove('active'));

    btn.classList.add('active');
    const tabId = 'tab-' + btn.dataset.tab;
    const section = document.getElementById(tabId);
    if (section) section.classList.add('active');

    this._onTabSwitch(btn.dataset.tab);
  }

  _onTabSwitch(tabName) {
    switch (tabName) {
      case 'distribute': distributionModule.refreshSelects(); break;
      case 'monitor': monitorModule.render(); break;
      case 'register': registrationModule.renderTable(); break;
      case 'centers': centersModule.render(); break;
    }
  }

  switchTo(tabName) {
    const btn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
    if (btn) this._switchTab(btn);
  }
}

class ProgressIndicator {
  static show(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;gap:10px;padding:30px;"><div class="spinner"></div><span style="color:var(--muted);">جارٍ التحميل...</span></div>`;
  }
  static hide(elementId) {
    const el = document.getElementById(elementId);
    if (el) el.innerHTML = '';
  }
}

class KeyboardShortcuts {
  constructor() {
    this.shortcuts = {
      'Ctrl+N': () => document.getElementById('fName')?.focus(),
      'Ctrl+F': () => document.getElementById('searchBox')?.focus(),
      'Escape': () => modal.closeAll(),
      'Ctrl+S': () => {
        const btn = document.getElementById('btnSubmit');
        if (btn && !btn.disabled) document.getElementById('frmMoatir')?.requestSubmit();
      }
    };
  }

  init() {
    document.addEventListener('keydown', (e) => {
      const key = [e.ctrlKey ? 'Ctrl' : '', e.key].filter(Boolean).join('+');
      const handler = this.shortcuts[key];
      if (handler) { e.preventDefault(); handler(); }
    });
  }
}

// ============================================================
// Bootstrap (No login required)
// ============================================================
function showBootstrapError(message, details) {
  console.error('❌ Bootstrap failed:', details || message);
  const el = document.getElementById('errorBanner');
  if (el) {
    el.style.display = 'block';
    el.textContent = message.includes('permission_denied')
      ? '⚠️ يجب نشر قواعد Firestore أولاً. افتح firebase console والصق محتوى firestore.rules.'
      : '⚠️ خطأ: ' + message;
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  try {
    firebaseService.init();
    await firebaseService.detectCollection();
    await searchComponent.init();
    await chartsManager.init();
    window.allEntries = {};
    centersModule.bindEvents();

    firebaseService.onEntriesChange((entries) => {
      window.allEntries = entries;
      registrationModule.updateEntries(entries);
      distributionModule.updateEntries(entries);
      monitorModule.updateEntries(entries);
      chartsManager.createStatsSummary(entries);
      chartsManager.createEducationChart('chartEducation', entries);
      chartsManager.createCenterChart('chartCenters', entries);
      chartsManager.createTimelineChart('chartTimeline', entries);
    });

    await firebaseService.seedDefaultCenters();

    firebaseService.onCentersChange((centersData) => {
      CONFIG.loadCentersFromFirestore(centersData);
      centersModule.updateCenters(CONFIG.CENTERS);
      distributionModule._fillCenterSelects();
      monitorModule._fillCenterFilter();
    });

    window.addEventListener('unhandledrejection', (event) => {
      console.error('Unhandled rejection:', event.reason);
      toast.error('حدث خطأ غير متوقع: ' + (event.reason?.message || 'خطأ تقني'));
    });

    console.log('✅ ANIE Platform initialized');
  } catch (error) {
    showBootstrapError(error.message, error);
  }
});
