/* ============================================================
   ANIE Platform - Configuration
   ============================================================ */

const CONFIG = {
  // Firebase Configuration
  firebase: {
    apiKey: "AIzaSyBNdeqW9mheWay22wGY5Kq84fXGksjHaUg",
    authDomain: "inti5ab.firebaseapp.com",
    projectId: "inti5ab",
    storageBucket: "inti5ab.firebasestorage.app",
    messagingSenderId: "145027777087",
    appId: "1:145027777087:web:301e1441bcbc424c616e8a",
    measurementId: "G-WBBLFBD534"
  },

  // Application Settings
  app: {
    name: 'منصة تسجيل المؤطرين',
    version: '2.0.0',
    collectionName: 'supervisors',
    itemsPerPage: 50,
    sessionDuration: 3600, // 1 hour in seconds
  },

  // Center & Position Data (Dynamic - loaded from Firestore)
  CENTERS: {
    "01": { name: "متقنة عمر إدريس", offices: [1, 2, 3, 4, 11, 12, 24, 30, 31, 38] },
    "02": { name: "مريقي محمد", offices: [5, 6, 7, 8, 13, 14, 25, 32, 39] },
    "03": { name: "طنجاوي الحاج", offices: [15, 16, 17, 18, 19, 26, 27, 33, 34, 40] },
    "04": { name: "قديم عطالله", offices: [20, 21, 22, 23, 28, 29, 35, 36, 37] },
    "05": { name: "شوشة السايح", offices: [9, 10] }
  },
  
  /**
   * Load centers from Firestore and merge into CENTERS
   * @param {Object} firestoreCenters - Centers data from Firestore
   */
  loadCentersFromFirestore(firestoreCenters) {
    if (!firestoreCenters || Object.keys(firestoreCenters).length === 0) return;
    
    // Clear existing centers and replace with Firestore data
    Object.keys(this.CENTERS).forEach(key => delete this.CENTERS[key]);
    
    Object.entries(firestoreCenters).forEach(([code, center]) => {
      this.CENTERS[code] = {
        name: center.name || `مركز ${code}`,
        offices: Array.isArray(center.offices) ? center.offices : []
      };
    });
    
    console.log(`✅ Loaded ${Object.keys(this.CENTERS).length} centers from Firestore`);
    
    // Re-calculate ALL_POSITIONS since it's a getter
    // (It will be recalculated automatically on next access)
    
    // Dispatch event for other modules to react
    document.dispatchEvent(new CustomEvent('centersUpdated', { 
      detail: { centers: this.CENTERS } 
    }));
  },

  OFFICE_TYPES: ["بلدي", "ولائي"],

  POSITIONS_ORDER: [
    "رئيس مكتب", "نائب رئيس مكتب", "كاتب",
    "مساعد أول", "مساعد ثاني", "إضافي أول", "إضافي ثاني"
  ],

  CENTER_POSITIONS: [
    "رئيس المركز", "مساعد المركز الأول", "مساعد المركز الثاني",
    "مساعد المركز الثالث", "مساعد المركز الرابع"
  ],

  EDUCATION_LEVELS: ["بدون مستوى", "إبتدائي", "متوسط", "ثانوي", "ليسانس", "ماستر", "ماجستير"],

  POSITION_COLORS: {
    "رئيس المركز": "#ef4444",
    "مساعد المركز الأول": "#f97316",
    "مساعد المركز الثاني": "#f97316",
    "مساعد المركز الثالث": "#f97316",
    "مساعد المركز الرابع": "#f97316",
    "رئيس مكتب": "#3d8bff",
    "نائب رئيس مكتب": "#5aa9ff",
    "كاتب": "#22c55e",
    "مساعد أول": "#f59e0b",
    "مساعد ثاني": "#f59e0b",
    "إضافي أول": "#a78bfa",
    "إضافي ثاني": "#a78bfa"
  },

  get ALL_POSITIONS() {
    return [...this.CENTER_POSITIONS, ...this.POSITIONS_ORDER];
  }
};

// Note: Intentionally NOT freezing CONFIG to allow loadCentersFromFirestore() 
// to dynamically update the CENTERS object with data from Firestore.
// If we froze it, centers added via the UI would never appear in the app.
