/* ============================================================
   ANIE Platform - Authentication Module
   ============================================================ */

class AuthManager {
  constructor() {
    this.auth = null;
    this.currentUser = null;
    this.isAuthenticated = false;
    this.onAuthStateChangedCallbacks = [];
    this._authReadyPromise = null;
    this._authReadyResolve = null;
  }

  /**
   * Initialize auth
   */
  init() {
    if (!firebaseService.initialized) {
      firebaseService.init();
    }
    
    this.auth = firebaseService.auth;

    // Create a promise that resolves when auth state is determined
    this._authReadyPromise = new Promise((resolve) => {
      this._authReadyResolve = resolve;
    });

    // Listen for auth state changes
    this.auth.onAuthStateChanged((user) => {
      this.currentUser = user;
      this.isAuthenticated = !!user;
      this._handleAuthChange(user);
      
      // Resolve the auth ready promise (the first time auth state is determined)
      if (this._authReadyResolve) {
        this._authReadyResolve(user);
        this._authReadyResolve = null;
      }
    });

    // Set up auth UI
    this._setupUI();
  }

  /**
   * Wait for auth state to be fully determined
   * @returns {Promise<Object|null>} The current user (or null if not authenticated)
   */
  async waitForAuthReady() {
    if (!this._authReadyPromise) {
      // If init() wasn't called yet, return a resolved promise
      return this.currentUser;
    }
    return this._authReadyPromise;
  }

  /**
   * Sign in with email and password
   */
  async signIn(email, password) {
    try {
      const result = await this.auth.signInWithEmailAndPassword(email, password);
      toast.success('تم تسجيل الدخول بنجاح ✅');
      return result.user;
    } catch (error) {
      this._handleAuthError(error);
      throw error;
    }
  }

  /**
   * Sign up with email and password
   */
  async signUp(email, password, name) {
    try {
      const result = await this.auth.createUserWithEmailAndPassword(email, password);
      
      // Update profile with display name
      await result.user.updateProfile({
        displayName: name
      });

      toast.success('تم إنشاء الحساب بنجاح ✅');
      return result.user;
    } catch (error) {
      this._handleAuthError(error);
      throw error;
    }
  }

  /**
   * Sign in with Google
   */
  async signInWithGoogle() {
    try {
      const provider = new firebase.auth.GoogleAuthProvider();
      provider.setCustomParameters({
        prompt: 'select_account'
      });
      const result = await this.auth.signInWithPopup(provider);
      toast.success('تم تسجيل الدخول بواسطة Google ✅');
      return result.user;
    } catch (error) {
      this._handleAuthError(error);
      throw error;
    }
  }

  /**
   * Sign out
   */
  async signOut() {
    try {
      await this.auth.signOut();
      toast.info('تم تسجيل الخروج');
      window.location.href = 'index.html';
    } catch (error) {
      toast.error('خطأ في تسجيل الخروج: ' + error.message);
    }
  }

  /**
   * Send password reset email
   */
  async resetPassword(email) {
    try {
      await this.auth.sendPasswordResetEmail(email);
      toast.success('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني');
    } catch (error) {
      this._handleAuthError(error);
      throw error;
    }
  }

  /**
   * Get current user
   */
  getCurrentUser() {
    return this.currentUser;
  }

  /**
   * Check if user is authenticated
   */
  isLoggedIn() {
    return this.isAuthenticated;
  }

  /**
   * Register callback for auth state changes
   */
  onAuthStateChanged(callback) {
    this.onAuthStateChangedCallbacks.push(callback);
    
    // Return unsubscribe function
    return () => {
      this.onAuthStateChangedCallbacks = 
        this.onAuthStateChangedCallbacks.filter(cb => cb !== callback);
    };
  }

  /**
   * Handle auth state changes
   */
  _handleAuthChange(user) {
    this.onAuthStateChangedCallbacks.forEach(callback => {
      try {
        callback(user);
      } catch (e) {
        console.error('Auth callback error:', e);
      }
    });
  }

  /**
   * Handle auth errors with Arabic messages
   */
  _handleAuthError(error) {
    let message = 'حدث خطأ غير متوقع';
    
    switch (error.code) {
      case 'auth/user-not-found':
        message = 'لا يوجد حساب بهذا البريد الإلكتروني';
        break;
      case 'auth/wrong-password':
        message = 'كلمة المرور غير صحيحة';
        break;
      case 'auth/email-already-in-use':
        message = 'هذا البريد الإلكتروني مستخدم بالفعل';
        break;
      case 'auth/weak-password':
        message = 'كلمة المرور ضعيفة جداً (6 أحرف على الأقل)';
        break;
      case 'auth/invalid-email':
        message = 'البريد الإلكتروني غير صحيح';
        break;
      case 'auth/too-many-requests':
        message = 'محاولات كثيرة جداً، الرجاء الانتظار ثم المحاولة مرة أخرى';
        break;
      case 'auth/network-request-failed':
        message = 'خطأ في الاتصال بالإنترنت';
        break;
      case 'auth/popup-closed-by-user':
        message = 'تم إغلاق نافذة تسجيل الدخول';
        break;
      case 'auth/cancelled-popup-request':
        message = 'تم إلغاء طلب تسجيل الدخول';
        break;
      default:
        message = error.message;
    }

    toast.error(message);
  }

  /**
   * Set up auth UI elements
   */
  _setupUI() {
    // Sign out button
    const signOutBtn = document.getElementById('btnSignOut');
    if (signOutBtn) {
      signOutBtn.addEventListener('click', () => this.signOut());
    }

    // Update user display name dynamically
    this._updateUserDisplay();
  }

  /**
   * Update user display name in the header
   */
  _updateUserDisplay() {
    const userDisplay = document.getElementById('userDisplay');
    const userNameEl = document.getElementById('userName');
    
    if (this.currentUser) {
      const displayName = this.currentUser.displayName || this.currentUser.email || 'مستخدم';
      if (userDisplay) {
        userDisplay.textContent = `👤 ${displayName}`;
      }
      if (userNameEl) {
        userNameEl.textContent = displayName;
      }
    } else {
      if (userDisplay) {
        userDisplay.textContent = '👤 غير متصل';
      }
    }
  }

  /**
   * Handle auth state changes - overridden to also update UI
   */
  _handleAuthChange(user) {
    this.currentUser = user;
    this.isAuthenticated = !!user;
    
    // Update UI dynamically
    this._updateUserDisplay();
    
    // Fire callbacks
    this.onAuthStateChangedCallbacks.forEach(callback => {
      try {
        callback(user);
      } catch (e) {
        console.error('Auth callback error:', e);
      }
    });
  }
}

// Export singleton
const authManager = new AuthManager();
