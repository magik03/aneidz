/* ============================================================
   ANIE Platform - Centers Management Module
   ============================================================ */

class CentersModule {
  constructor() {
    this.allCenters = {};
    this.currentEditId = null;
    this.currentDeleteId = null;
    this._eventsBound = false;
  }

  /**
   * Initialize centers module
   */
  init(allCenters) {
    this.allCenters = allCenters || {};
    this.bindEvents();
    this.render();
  }

  /**
   * Bind DOM events independently of Firestore data
   * This ensures the "إضافة مركز جديد" button works even if Firestore is slow
   */
  bindEvents() {
    if (this._eventsBound) return;
    this._setupEventListeners();
    this._eventsBound = true;
  }

  /**
   * Update centers data
   */
  updateCenters(centers) {
    this.allCenters = centers || {};
    this.bindEvents();
    this.render();
  }

  /**
   * Render centers management interface
   */
  render() {
    const container = document.getElementById('centersContent');
    if (!container) return;

    container.innerHTML = '';

    const centerCodes = Object.keys(this.allCenters);

    if (centerCodes.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="display:block;">
          <div class="icon">🏛️</div>
          <div>لا توجد مراكز مسجّلة بعد. أضف أول مركز الآن.</div>
        </div>
      `;
      return;
    }

    // Create center cards
    centerCodes.forEach(code => {
      const center = this.allCenters[code];
      const card = this._createCenterCard(code, center);
      container.appendChild(card);
    });
  }

  /**
   * Create a center card
   */
  _createCenterCard(code, center) {
    const card = document.createElement('div');
    card.className = 'center-card stagger';

    // Count how many moatirin are assigned to this center
    const assignedCount = this._countAssignedMoatirin(code);

    // Format offices list
    const officesList = Array.isArray(center.offices) && center.offices.length > 0
      ? center.offices.sort((a, b) => a - b).map(o => `<span class="office-tag">مكتب ${o}</span>`).join('')
      : '<span style="color:var(--muted); font-size:13px;">لا توجد مكاتب</span>';

    card.innerHTML = `
      <div class="center-card-header">
        <div>
          <span class="center-card-code">${code}</span>
          <span class="center-card-name">${Helpers.escapeHtml(center.name)}</span>
        </div>
        <span class="center-card-count">${assignedCount} مؤطر</span>
      </div>
      <div class="center-card-body">
        <div class="offices-list">
          <span class="offices-label">المكاتب:</span>
          <div class="offices-tags">${officesList}</div>
        </div>
      </div>
      <div class="center-card-actions">
        <button class="btn-secondary btn-small btn-edit-center" data-code="${code}">✏️ تعديل</button>
        <button class="btn-danger btn-small btn-delete-center" data-code="${code}">🗑️ حذف</button>
      </div>
    `;

    // Add event listeners for this card
    card.querySelector('.btn-edit-center').addEventListener('click', () => this._openEditCenter(code));
    card.querySelector('.btn-delete-center').addEventListener('click', () => this._openDeleteCenter(code));

    return card;
  }

  /**
   * Count how many moatirin are assigned to a center
   */
  _countAssignedMoatirin(centerCode) {
    let count = 0;
    // We need access to the entries - try via window/global
    const entries = window.allEntries || {};
    Object.values(entries).forEach(e => {
      if (e.center === centerCode && e.assignLevel) count++;
    });
    return count;
  }

  /**
   * Open add center form
   */
  showAddForm() {
    this.currentEditId = null;
    document.getElementById('centerFormTitle').textContent = 'إضافة مركز جديد';
    document.getElementById('cCode').value = '';
    document.getElementById('cCode').disabled = false;
    document.getElementById('cName').value = '';
    document.getElementById('cOffices').value = '';
    document.getElementById('btnSaveCenter').textContent = 'إضافة المركز';
    document.getElementById('btnSaveCenter').className = 'btn-primary';
    
    modal.show('centerModal');
  }

  /**
   * Open edit center form
   */
  _openEditCenter(code) {
    const center = this.allCenters[code];
    if (!center) return;

    this.currentEditId = code;
    document.getElementById('centerFormTitle').textContent = 'تعديل المركز';
    document.getElementById('cCode').value = code;
    document.getElementById('cCode').disabled = true; // Code cannot be changed
    document.getElementById('cName').value = center.name || '';
    document.getElementById('cOffices').value = Array.isArray(center.offices) 
      ? center.offices.join(', ') 
      : '';
    document.getElementById('btnSaveCenter').textContent = 'حفظ التعديلات';
    document.getElementById('btnSaveCenter').className = 'btn-primary';
    
    modal.show('centerModal');
  }

  /**
   * Save center (add or update)
   */
  async _saveCenter() {
    const code = document.getElementById('cCode').value.trim();
    const name = document.getElementById('cName').value.trim();
    const officesStr = document.getElementById('cOffices').value.trim();

    // Validation
    if (!code) {
      toast.error('يرجى إدخال رمز المركز');
      return;
    }
    if (!name) {
      toast.error('يرجى إدخال اسم المركز');
      return;
    }

    // Parse offices
    let offices = [];
    if (officesStr) {
      offices = officesStr.split(',')
        .map(o => o.trim())
        .filter(o => o !== '')
        .map(o => parseInt(o))
        .filter(o => !isNaN(o) && o > 0);

      if (offices.length === 0 && officesStr) {
        toast.error('يرجى إدخال أرقام مكاتب صحيحة (أرقام مفصولة بفواصل)');
        return;
      }
    }

    // Check if code already exists (for new center)
    if (!this.currentEditId && this.allCenters[code]) {
      toast.error('رمز المركز موجود مسبقاً. استخدم رمزاً آخر.');
      return;
    }

    const btn = document.getElementById('btnSaveCenter');
    btn.disabled = true;
    btn.textContent = 'جارٍ الحفظ...';

    try {
      if (this.currentEditId) {
        // Update existing center
        await firebaseService.updateCenter(this.currentEditId, {
          name,
          offices
        });
        toast.success('تم تحديث المركز بنجاح ✅');
      } else {
        // Add new center with the code as document ID
        await firebaseService.updateCenter(code, {
          name,
          offices
        });
        toast.success('تم إضافة المركز بنجاح ✅');
      }
      
      modal.close();
      this.currentEditId = null;
    } catch (err) {
      toast.error('خطأ أثناء الحفظ: ' + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = this.currentEditId ? 'حفظ التعديلات' : 'إضافة المركز';
    }
  }

  /**
   * Open delete center confirmation
   */
  _openDeleteCenter(code) {
    this.currentDeleteId = code;
    const center = this.allCenters[code];
    const name = center ? center.name : code;

    // Check if there are moatirin assigned to this center
    const assignedCount = this._countAssignedMoatirin(code);

    const modalBody = document.getElementById('deleteCenterBody');
    if (modalBody) {
      if (assignedCount > 0) {
        modalBody.innerHTML = `
          <p>هل أنت متأكد من حذف المركز <b>${Helpers.escapeHtml(name)} (${code})</b>؟</p>
          <p style="color:var(--danger); font-weight:700; margin-top:10px;">
            ⚠️ يوجد <b>${assignedCount}</b> مؤطر موزّع على هذا المركز. 
            سيتم إلغاء توزيعهم جميعاً.
          </p>
        `;
      } else {
        modalBody.innerHTML = `
          <p>هل أنت متأكد من حذف المركز <b>${Helpers.escapeHtml(name)} (${code})</b>؟</p>
          <p style="color:var(--muted); font-size:13px; margin-top:8px;">لا يمكن التراجع عن هذا الإجراء.</p>
        `;
      }
    }

    modal.show('deleteCenterModal');
  }

  /**
   * Confirm delete center
   */
  async _confirmDeleteCenter() {
    if (!this.currentDeleteId) return;

    const btn = document.getElementById('btnConfirmDeleteCenter');
    btn.disabled = true;
    btn.textContent = 'جارٍ الحذف...';

    try {
      // Delete the center document
      await firebaseService.deleteCenter(this.currentDeleteId);
      
      // Unassign all moatirin assigned to this center
      const entries = window.allEntries || {};
      for (const [id, e] of Object.entries(entries)) {
        if (e.center === this.currentDeleteId && e.assignLevel) {
          await firebaseService.updateEntry(id, {
            assignLevel: null,
            center: null,
            centerPosition: null,
            officeNumber: null,
            officeType: null,
            officePosition: null
          });
        }
      }

      modal.close();
      toast.success('تم حذف المركز وإلغاء توزيع المؤطرين المرتبطين به');
      this.currentDeleteId = null;
    } catch (err) {
      toast.error('خطأ أثناء الحذف: ' + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = 'حذف المركز';
    }
  }

  /**
   * Set up event listeners
   */
  _setupEventListeners() {
    // Add center button
    const btnAddCenter = document.getElementById('btnAddCenter');
    if (btnAddCenter) {
      btnAddCenter.addEventListener('click', () => this.showAddForm());
    }

    // Save center button
    const btnSaveCenter = document.getElementById('btnSaveCenter');
    if (btnSaveCenter) {
      btnSaveCenter.addEventListener('click', () => this._saveCenter());
    }

    // Cancel center modal
    const btnCancelCenter = document.getElementById('btnCancelCenter');
    if (btnCancelCenter) {
      btnCancelCenter.addEventListener('click', () => {
        modal.close();
        this.currentEditId = null;
      });
    }

    // Confirm delete center
    const btnConfirmDelete = document.getElementById('btnConfirmDeleteCenter');
    if (btnConfirmDelete) {
      btnConfirmDelete.addEventListener('click', () => this._confirmDeleteCenter());
    }

    // Cancel delete center
    const btnCancelDelete = document.getElementById('btnCancelDeleteCenter');
    if (btnCancelDelete) {
      btnCancelDelete.addEventListener('click', () => {
        modal.close();
        this.currentDeleteId = null;
      });
    }
  }
}

// Export singleton
const centersModule = new CentersModule();

