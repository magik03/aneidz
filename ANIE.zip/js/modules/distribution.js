/* ============================================================
   ANIE Platform - Distribution Module
   ============================================================ */

class DistributionModule {
  constructor() {
    this.allEntries = {};
    this._eventsInitialized = false;
  }

  /**
   * Initialize distribution module
   */
  init(allEntries) {
    this.allEntries = allEntries;
    this._setupEventListeners();
    this._fillCenterSelects();
    this._eventsInitialized = true;
  }

  /**
   * Update entries data
   */
  updateEntries(entries) {
    this.allEntries = entries;
    if (!this._eventsInitialized) {
      this._setupEventListeners();
      this._fillCenterSelects();
      this._eventsInitialized = true;
    }
    this.refreshSelects();
  }

  /**
   * Refresh distribution selects
   */
  refreshSelects() {
    this._fillMoatirSelect();
    this._checkExistingAssignment();
  }

  /**
   * Fill center selects
   */
  _fillCenterSelects() {
    const sel = document.getElementById('dCenter');
    if (!sel) return;

    sel.innerHTML = '<option value="" disabled selected>اختر المركز...</option>';
    Object.keys(CONFIG.CENTERS).forEach(code => {
      const opt = document.createElement('option');
      opt.value = code;
      opt.textContent = Helpers.centerLabel(code);
      sel.appendChild(opt);
    });
  }

  /**
   * Fill moatir select
   */
  _fillMoatirSelect() {
    const sel = document.getElementById('dMoatir');
    if (!sel) return;

    const currentVal = sel.value;
    sel.innerHTML = '<option value="" disabled selected>اختر مؤطراً...</option>';

    const ids = Object.keys(this.allEntries).sort((a, b) =>
      (this.allEntries[a].createdAt || 0) - (this.allEntries[b].createdAt || 0)
    );

    ids.forEach(id => {
      const e = this.allEntries[id];
      const opt = document.createElement('option');
      opt.value = id;
      opt.textContent = this._getMoatirLabel(e);
      sel.appendChild(opt);
    });

    if (currentVal && this.allEntries[currentVal]) {
      sel.value = currentVal;
    }

    this._checkExistingAssignment();
  }

  /**
   * Get moatir label with assignment status
   */
  _getMoatirLabel(e) {
    let tag = ' [غير موزّع]';
    if (e.assignLevel === 'office' && e.center) {
      tag = ` [موزّع: ${Helpers.centerLabel(e.center)} - مكتب ${e.officeNumber} ${e.officeType} - ${e.officePosition}]`;
    } else if (e.assignLevel === 'center' && e.center) {
      tag = ` [موزّع: ${Helpers.centerLabel(e.center)} - ${e.centerPosition}]`;
    }
    return `${e.name} ${e.lastName}${tag}`;
  }

  /**
   * Handle center change
   */
  _onCenterChange() {
    const officeSel = document.getElementById('dOffice');
    if (!officeSel) return;

    const code = document.getElementById('dCenter').value;
    officeSel.innerHTML = '';

    if (!code) {
      officeSel.disabled = true;
      officeSel.innerHTML = '<option value="" disabled selected>اختر المركز أولاً</option>';
      return;
    }

    officeSel.disabled = false;
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.disabled = true;
    placeholder.selected = true;
    placeholder.textContent = 'اختر المكتب...';
    officeSel.appendChild(placeholder);

    CONFIG.CENTERS[code].offices.forEach(num => {
      const opt = document.createElement('option');
      opt.value = num;
      opt.textContent = 'مكتب ' + num;
      officeSel.appendChild(opt);
    });

    this._checkExistingAssignment();
  }

  /**
   * Handle level change (office/center)
   */
  _onLevelChange() {
    const isOffice = document.getElementById('dLevel').value === 'office';
    document.getElementById('fieldOffice').style.display = isOffice ? '' : 'none';
    document.getElementById('fieldOfficeType').style.display = isOffice ? '' : 'none';
    document.getElementById('fieldOfficePosition').style.display = isOffice ? '' : 'none';
    document.getElementById('fieldCenterPosition').style.display = isOffice ? 'none' : '';
    document.getElementById('conflictCard').style.display = 'none';
  }

  /**
   * Check existing assignment for selected moatir
   */
  _checkExistingAssignment() {
    const box = document.getElementById('currentAssignmentBox');
    const moatirId = document.getElementById('dMoatir').value;
    const e = this.allEntries[moatirId];

    if (!moatirId || !e || !e.assignLevel) {
      box.style.display = 'none';
      return;
    }

    box.style.display = 'block';
    if (e.assignLevel === 'office') {
      box.innerHTML = `هذا المؤطر موزَّع حالياً على: <b>${Helpers.centerLabel(e.center)} — مكتب ${e.officeNumber} (${e.officeType}) — ${Helpers.escapeHtml(e.officePosition)}</b>`;
    } else {
      box.innerHTML = `هذا المؤطر موزَّع حالياً على: <b>${Helpers.centerLabel(e.center)} — ${Helpers.escapeHtml(e.centerPosition)} (طاقم المركز)</b>`;
    }
  }

  /**
   * Handle distribute button
   */
  async handleDistribute() {
    const moatirId = document.getElementById('dMoatir').value;
    const level = document.getElementById('dLevel').value;
    const center = document.getElementById('dCenter').value;
    const conflictCard = document.getElementById('conflictCard');

    const validation = Validators.validateDistributionForm({
      moatirId,
      level,
      center,
      officeNumber: document.getElementById('dOffice').value,
      officeType: document.getElementById('dOfficeType').value,
      officePosition: document.getElementById('dOfficePosition').value,
      centerPosition: document.getElementById('dCenterPosition').value
    });

    if (!validation.valid) {
      const firstError = Object.values(validation.errors)[0];
      toast.error(firstError);
      return;
    }

    if (level === 'office') {
      const officeNumber = document.getElementById('dOffice').value;
      const officeType = document.getElementById('dOfficeType').value;
      const officePosition = document.getElementById('dOfficePosition').value;

      // Check for conflict
      const conflictId = this._findConflict(moatirId, center, officeNumber, officeType, officePosition, 'office');

      if (conflictId) {
        this._showConflict(conflictId, center, officeNumber, officeType, officePosition, 'office');
        toast.error('لم يتم التوزيع — المقعد مشغول');
        return;
      }

      conflictCard.style.display = 'none';
      try {
        await firebaseService.updateEntry(moatirId, {
          assignLevel: 'office',
          center,
          officeNumber,
          officeType,
          officePosition,
          centerPosition: null
        });
        toast.success('تم توزيع المؤطر بنجاح ✅');
        this.refreshSelects();
      } catch (err) {
        toast.error('خطأ: ' + err.message);
      }
    } else {
      const centerPosition = document.getElementById('dCenterPosition').value;

      const conflictId = this._findConflict(moatirId, center, null, null, centerPosition, 'center');

      if (conflictId) {
        this._showConflict(conflictId, center, null, null, centerPosition, 'center');
        toast.error('لم يتم التوزيع — المنصب مشغول');
        return;
      }

      conflictCard.style.display = 'none';
      try {
        await firebaseService.updateEntry(moatirId, {
          assignLevel: 'center',
          center,
          centerPosition,
          officeNumber: null,
          officeType: null,
          officePosition: null
        });
        toast.success('تم توزيع المؤطر بنجاح ✅');
        this.refreshSelects();
      } catch (err) {
        toast.error('خطأ: ' + err.message);
      }
    }
  }

  /**
   * Find conflict for a seat
   */
  _findConflict(moatirId, center, officeNumber, officeType, position, level) {
    for (const [id, e] of Object.entries(this.allEntries)) {
      if (id === moatirId) continue;

      if (level === 'office') {
        if (e.assignLevel === 'office' &&
            e.center === center &&
            String(e.officeNumber) === String(officeNumber) &&
            e.officeType === officeType &&
            e.officePosition === position) {
          return id;
        }
      } else {
        if (e.assignLevel === 'center' &&
            e.center === center &&
            e.centerPosition === position) {
          return id;
        }
      }
    }
    return null;
  }

  /**
   * Show conflict info
   */
  _showConflict(conflictId, center, officeNumber, officeType, position, level) {
    const c = this.allEntries[conflictId];
    if (!c) return;

    const conflictCard = document.getElementById('conflictCard');
    const conflictInfo = document.getElementById('conflictInfo');

    conflictCard.style.display = 'block';

    if (level === 'office') {
      conflictInfo.innerHTML = `
        <p style="margin:0 0 10px; color:var(--muted); font-size:13.5px;">
          منصب <b style="color:var(--text);">${Helpers.escapeHtml(position)}</b> في
          <b style="color:var(--text);">${Helpers.centerLabel(center)} - مكتب ${officeNumber} (${officeType})</b>
          مشغول حالياً من طرف:
        </p>
        <div class="table-wrap">
          <table>
            <thead><tr><th>الاسم واللقب</th><th>الرقم الانتخابي</th><th>الهاتف</th></tr></thead>
            <tbody>
              <tr>
                <td>${Helpers.escapeHtml(c.name)} ${Helpers.escapeHtml(c.lastName)}</td>
                <td>${c.electoralNum ? Helpers.escapeHtml(c.electoralNum) : '—'}</td>
                <td>${c.phone ? Helpers.escapeHtml(c.phone) : '—'}</td>
              </tr>
            </tbody>
          </table>
        </div>
      `;
    } else {
      conflictInfo.innerHTML = `
        <p style="margin:0 0 10px; color:var(--muted); font-size:13.5px;">
          منصب <b style="color:var(--text);">${Helpers.escapeHtml(position)}</b> في
          <b style="color:var(--text);">${Helpers.centerLabel(center)} (طاقم المركز)</b>
          مشغول حالياً من طرف:
        </p>
        <div class="table-wrap">
          <table>
            <thead><tr><th>الاسم واللقب</th><th>الرقم الانتخابي</th><th>الهاتف</th></tr></thead>
            <tbody>
              <tr>
                <td>${Helpers.escapeHtml(c.name)} ${Helpers.escapeHtml(c.lastName)}</td>
                <td>${c.electoralNum ? Helpers.escapeHtml(c.electoralNum) : '—'}</td>
                <td>${c.phone ? Helpers.escapeHtml(c.phone) : '—'}</td>
              </tr>
            </tbody>
          </table>
        </div>
      `;
    }
  }

  /**
   * Handle unassign button
   */
  async handleUnassign() {
    const moatirId = document.getElementById('dMoatir').value;
    if (!moatirId) {
      toast.error('يرجى اختيار المؤطر أولاً');
      return;
    }

    try {
      await firebaseService.updateEntry(moatirId, {
        assignLevel: null,
        center: null,
        centerPosition: null,
        officeNumber: null,
        officeType: null,
        officePosition: null
      });
      toast.success('تم إلغاء توزيع المؤطر');
      document.getElementById('conflictCard').style.display = 'none';
      this.refreshSelects();
    } catch (err) {
      toast.error('خطأ: ' + err.message);
    }
  }

  /**
   * Set up event listeners
   */
  _setupEventListeners() {
    // Center change
    const dCenter = document.getElementById('dCenter');
    if (dCenter) {
      dCenter.addEventListener('change', () => this._onCenterChange());
    }

    // Level change
    const dLevel = document.getElementById('dLevel');
    if (dLevel) {
      dLevel.addEventListener('change', () => this._onLevelChange());
    }

    // Moatir change
    const dMoatir = document.getElementById('dMoatir');
    if (dMoatir) {
      dMoatir.addEventListener('change', () => this._checkExistingAssignment());
    }

    // Distribute button
    const btnDistribute = document.getElementById('btnDistribute');
    if (btnDistribute) {
      btnDistribute.addEventListener('click', () => this.handleDistribute());
    }

    // Unassign button
    const btnUnassign = document.getElementById('btnUnassign');
    if (btnUnassign) {
      btnUnassign.addEventListener('click', () => this.handleUnassign());
    }

    // Other fields that trigger assignment check
    ['dOffice', 'dOfficeType', 'dOfficePosition', 'dCenterPosition'].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', () => this._checkExistingAssignment());
      }
    });
  }
}

// Export singleton
const distributionModule = new DistributionModule();
