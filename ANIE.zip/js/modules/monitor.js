/* ============================================================
   ANIE Platform - Monitor Module
   ============================================================ */

class MonitorModule {
  constructor() {
    this.allEntries = {};
    this._eventsInitialized = false;
  }

  /**
   * Initialize monitor module
   */
  init(allEntries) {
    this.allEntries = allEntries;
    this._setupEventListeners();
    this._fillCenterFilter();
    this._eventsInitialized = true;
  }

  /**
   * Update entries data
   */
  updateEntries(entries) {
    this.allEntries = entries;
    if (!this._eventsInitialized) {
      this._setupEventListeners();
      this._fillCenterFilter();
      this._eventsInitialized = true;
    }
    this.render();
  }

  /**
   * Render monitor dashboard
   */
  render() {
    const container = document.getElementById('monitorContent');
    if (!container) return;

    container.innerHTML = '';

    const filterCenter = document.getElementById('monFilterCenter').value;
    const filterStatus = document.getElementById('monFilterStatus').value;

    const centersToShow = filterCenter ? [filterCenter] : Object.keys(CONFIG.CENTERS);

    centersToShow.forEach(code => {
      const center = CONFIG.CENTERS[code];
      const seats = this._buildSeats(code, center);
      const totalSeats = seats.length;
      const filledCount = seats.filter(s => s.occupantId).length;

      let visibleSeats = seats;
      if (filterStatus === 'filled') {
        visibleSeats = seats.filter(s => s.occupantId);
      } else if (filterStatus === 'empty') {
        visibleSeats = seats.filter(s => !s.occupantId);
      } else if (filterStatus === 'flagged') {
        visibleSeats = seats.filter(s => s.occupantId && this.allEntries[s.occupantId]?.flagged);
      }

      const block = this._createCenterBlock(code, center, visibleSeats, totalSeats, filledCount);
      container.appendChild(block);
    });

    if (centersToShow.length === 0) {
      container.innerHTML = '<div class="no-results-msg">لا توجد مراكز مطابقة.</div>';
    }
  }

  /**
   * Build seats for a center
   */
  _buildSeats(code, center) {
    const seats = [];

    // Center positions
    CONFIG.CENTER_POSITIONS.forEach(pos => {
      const occupantId = this._findOccupant(code, 'center', null, null, pos);
      seats.push({
        level: 'center',
        officeLabel: 'طاقم المركز',
        type: null,
        position: pos,
        occupantId
      });
    });

    // Office positions
    center.offices.forEach(officeNum => {
      CONFIG.OFFICE_TYPES.forEach(type => {
        CONFIG.POSITIONS_ORDER.forEach(pos => {
          const occupantId = this._findOccupant(code, 'office', officeNum, type, pos);
          seats.push({
            level: 'office',
            officeLabel: 'مكتب ' + officeNum,
            type,
            position: pos,
            occupantId
          });
        });
      });
    });

    return seats;
  }

  /**
   * Find occupant for a specific seat
   */
  _findOccupant(centerCode, level, officeNumber, officeType, position) {
    for (const [id, e] of Object.entries(this.allEntries)) {
      if (!e.assignLevel) continue;

      if (level === 'center') {
        if (e.assignLevel === 'center' && e.center === centerCode && e.centerPosition === position) {
          return id;
        }
      } else {
        if (e.assignLevel === 'office' &&
            e.center === centerCode &&
            String(e.officeNumber) === String(officeNumber) &&
            e.officeType === officeType &&
            e.officePosition === position) {
          return id;
        }
      }
    }
    return null;
  }

  /**
   * Create center block HTML
   */
  _createCenterBlock(code, center, visibleSeats, totalSeats, filledCount) {
    const block = document.createElement('div');
    block.className = 'center-block stagger';

    let tableHtml = '';
    let cardsHtml = '';

    if (visibleSeats.length === 0) {
      tableHtml = '<div class="no-results-msg">لا توجد نتائج مطابقة لهذا الفلتر.</div>';
    } else {
      // Build table rows
      const tableRows = visibleSeats.map(s => {
        const typeTag = s.level === 'center'
          ? '<span class="lvl-tag center">طاقم المركز</span>'
          : `<span class="lvl-tag ${s.type === 'بلدي' ? 'baladi' : 'wilaya'}">${s.type}</span>`;

        if (s.occupantId) {
          const e = this.allEntries[s.occupantId];
          const rowClass = e.flagged ? 'row-flagged' : 'row-filled';
          const flagTxt = e.flagged
            ? `<span style="color:#ff9c9c; font-weight:700;">🚩 ${Helpers.escapeHtml(e.issueType || 'مشكلة')}</span>`
            : '—';

          return `<tr class="${rowClass}">
            <td>${typeTag}</td>
            <td>${Helpers.escapeHtml(s.officeLabel)}</td>
            <td>${Helpers.escapeHtml(s.position)}</td>
            <td style="color:#a3f0bd; font-weight:700;">مشغول</td>
            <td>${Helpers.escapeHtml(e.name)} ${Helpers.escapeHtml(e.lastName)}</td>
            <td>${e.birth ? Helpers.formatDate(e.birth) : 'غير مسجَّل'}</td>
            <td>${e.phone ? Helpers.escapeHtml(e.phone) : 'غير مسجَّل'}</td>
            <td>${flagTxt}</td>
          </tr>`;
        }

        return `<tr class="row-empty">
          <td>${typeTag}</td>
          <td>${Helpers.escapeHtml(s.officeLabel)}</td>
          <td>${Helpers.escapeHtml(s.position)}</td>
          <td>شاغر</td>
          <td>—</td><td>—</td><td>—</td><td>—</td>
        </tr>`;
      }).join('');

      // Build mobile cards
      const cardItems = visibleSeats.map(s => {
        const typeTag = s.level === 'center'
          ? '<span class="lvl-tag center">طاقم المركز</span>'
          : `<span class="lvl-tag ${s.type === 'بلدي' ? 'baladi' : 'wilaya'}">${s.type}</span>`;

        if (s.occupantId) {
          const e = this.allEntries[s.occupantId];
          const cardClass = e.flagged ? 'row-flagged' : '';
          const flagTxt = e.flagged
            ? `<span style="color:#ff9c9c; font-weight:700;">🚩 ${Helpers.escapeHtml(e.issueType || 'مشكلة')}</span>`
            : '—';

          return `<div class="row-card mon-card ${cardClass}">
            <div class="rc-head">
              <div class="rc-name">${Helpers.escapeHtml(e.name)} ${Helpers.escapeHtml(e.lastName)}</div>
              ${typeTag}
            </div>
            <div class="rc-fields">
              <div class="rc-field"><span class="rc-label">المكتب</span><span class="rc-value">${Helpers.escapeHtml(s.officeLabel)}</span></div>
              <div class="rc-field"><span class="rc-label">المنصب</span><span class="rc-value">${Helpers.escapeHtml(s.position)}</span></div>
              <div class="rc-field"><span class="rc-label">الحالة</span><span class="rc-value" style="color:#a3f0bd; font-weight:700;">مشغول</span></div>
              <div class="rc-field"><span class="rc-label">تاريخ الميلاد</span><span class="rc-value">${e.birth ? Helpers.formatDate(e.birth) : 'غير مسجَّل'}</span></div>
              <div class="rc-field"><span class="rc-label">الهاتف</span><span class="rc-value">${e.phone ? Helpers.escapeHtml(e.phone) : 'غير مسجَّل'}</span></div>
              <div class="rc-field"><span class="rc-label">ملاحظة/مشكلة</span><span class="rc-value">${flagTxt}</span></div>
            </div>
          </div>`;
        }

        return `<div class="row-card mon-card row-empty">
          <div class="rc-head">
            <div class="rc-name" style="color:var(--muted);">شاغر</div>
            ${typeTag}
          </div>
          <div class="rc-fields">
            <div class="rc-field"><span class="rc-label">المكتب</span><span class="rc-value">${Helpers.escapeHtml(s.officeLabel)}</span></div>
            <div class="rc-field"><span class="rc-label">المنصب</span><span class="rc-value">${Helpers.escapeHtml(s.position)}</span></div>
          </div>
        </div>`;
      }).join('');

      tableHtml = `
        <div class="mon-table-wrap">
          <table class="mon-table">
            <thead>
              <tr>
                <th>المستوى</th><th>المكتب</th><th>المنصب</th><th>الحالة</th>
                <th>الاسم واللقب</th><th>تاريخ الميلاد</th><th>الهاتف</th><th>ملاحظة/مشكلة</th>
              </tr>
            </thead>
            <tbody>${tableRows}</tbody>
          </table>
          <div class="cards-list" style="padding:0 14px 14px;">${cardItems}</div>
        </div>`;
    }

    block.innerHTML = `
      <div class="center-header">
        <span>${Helpers.centerLabel(code)}</span>
        <span class="center-progress">${filledCount} / ${totalSeats} مقعد مشغول</span>
      </div>
      ${tableHtml}
    `;

    return block;
  }

  /**
   * Fill center filter select
   */
  _fillCenterFilter() {
    const sel = document.getElementById('monFilterCenter');
    if (!sel) return;

    sel.innerHTML = '<option value="">كل المراكز</option>';
    Object.keys(CONFIG.CENTERS).forEach(code => {
      const opt = document.createElement('option');
      opt.value = code;
      opt.textContent = Helpers.centerLabel(code);
      sel.appendChild(opt);
    });
  }

  /**
   * Set up event listeners
   */
  _setupEventListeners() {
    const monCenter = document.getElementById('monFilterCenter');
    if (monCenter) {
      monCenter.addEventListener('change', () => this.render());
    }

    const monStatus = document.getElementById('monFilterStatus');
    if (monStatus) {
      monStatus.addEventListener('change', () => this.render());
    }

    // Export buttons
    const btnExportAll = document.getElementById('btnExportAll');
    if (btnExportAll) {
      btnExportAll.addEventListener('click', () => ExportUtils.exportToExcel(this.allEntries, false));
    }

    const btnExportAssigned = document.getElementById('btnExportAssigned');
    if (btnExportAssigned) {
      btnExportAssigned.addEventListener('click', () => ExportUtils.exportToExcel(this.allEntries, true));
    }
  }
}

// Export singleton
const monitorModule = new MonitorModule();
