/* ============================================================
   ANIE Platform - Registration Module
   ============================================================ */

class RegistrationModule {
  constructor() {
    this.allEntries = {};
    this.currentEditId = null;
    this.currentFlagId = null;
    this.currentDeleteId = null;
    this._eventsInitialized = false;
  }

  /**
   * Initialize registration module
   */
  init(allEntries) {
    this.allEntries = allEntries;
    this._setupEventListeners();
    this._setupSearch();
    this._eventsInitialized = true;
  }

  /**
   * Update entries data
   */
  updateEntries(entries) {
    this.allEntries = entries;
    if (!this._eventsInitialized) {
      this._setupEventListeners();
      this._setupSearch();
      this._eventsInitialized = true;
    }
    this.renderTable();
    searchComponent.updateEntries(Object.values(entries));
  }

  /**
   * Render the registration table
   */
  renderTable(filteredEntries = null) {
    const entries = filteredEntries || Object.values(this.allEntries);
    const tbody = document.getElementById('tblBody');
    const cardsList = document.getElementById('tblCards');
    
    if (!tbody || !cardsList) return;

    tbody.innerHTML = '';
    cardsList.innerHTML = '';

    const totalCount = Object.keys(this.allEntries).length;
    const counter = document.getElementById('totalCounter');
    if (counter) {
      counter.innerHTML = `<b>${totalCount}</b> مسجّل`;
    }

    if (entries.length === 0) {
      document.getElementById('emptyState').style.display = 'block';
      return;
    }

    document.getElementById('emptyState').style.display = 'none';
    const sortedEntries = Helpers.sortEntries(entries);

    sortedEntries.forEach(entry => {
      const id = this._getEntryId(entry);
      const currentPos = Helpers.getEntryPosition(entry);
      const color = Helpers.getPositionColor(currentPos);

      const distributionTxt = this._getDistributionText(entry);
      const positionTxt = this._getPositionBadge(currentPos, color);
      const flagNote = this._getFlagNote(entry);

      // Table row
      const tr = document.createElement('tr');
      if (entry.flagged) tr.className = 'flagged-row';
      tr.innerHTML = `
        <td>${Helpers.escapeHtml(entry.name)} ${Helpers.escapeHtml(entry.lastName)}${flagNote}</td>
        <td>${entry.birth ? Helpers.formatDate(entry.birth) : '—'}</td>
        <td>${entry.electoralNum ? Helpers.escapeHtml(entry.electoralNum) : '—'}</td>
        <td>${entry.phone ? Helpers.escapeHtml(entry.phone) : '—'}</td>
        <td>${positionTxt}</td>
        <td>${distributionTxt}</td>
        <td>${entry.notes ? Helpers.escapeHtml(entry.notes) : '—'}</td>
        <td>
          <div class="row-actions">
            <button class="btn-secondary btn-small" onclick="registrationModule.openEdit('${id}')">تعديل</button>
            <button class="btn-flag btn-small ${entry.flagged ? 'active' : ''}" onclick="registrationModule.openFlag('${id}')">🚩</button>
            <button class="btn-danger btn-small" onclick="registrationModule.openDelete('${id}')">حذف</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);

      // Mobile card
      const card = document.createElement('div');
      card.className = 'row-card' + (entry.flagged ? ' flagged-row' : '');
      card.innerHTML = `
        <div class="rc-head">
          <div class="rc-name">${Helpers.escapeHtml(entry.name)} ${Helpers.escapeHtml(entry.lastName)}${flagNote}</div>
          ${positionTxt}
        </div>
        <div class="rc-fields">
          <div class="rc-field"><span class="rc-label">تاريخ الميلاد</span><span class="rc-value">${entry.birth ? Helpers.formatDate(entry.birth) : '—'}</span></div>
          <div class="rc-field"><span class="rc-label">الرقم الانتخابي</span><span class="rc-value">${entry.electoralNum ? Helpers.escapeHtml(entry.electoralNum) : '—'}</span></div>
          <div class="rc-field"><span class="rc-label">الهاتف</span><span class="rc-value">${entry.phone ? Helpers.escapeHtml(entry.phone) : '—'}</span></div>
          <div class="rc-field"><span class="rc-label">التوزيع</span><span class="rc-value">${distributionTxt}</span></div>
          <div class="rc-field"><span class="rc-label">ملاحظات</span><span class="rc-value">${entry.notes ? Helpers.escapeHtml(entry.notes) : '—'}</span></div>
        </div>
        <div class="rc-actions">
          <button class="btn-secondary btn-small" onclick="registrationModule.openEdit('${id}')">تعديل</button>
          <button class="btn-flag btn-small ${entry.flagged ? 'active' : ''}" onclick="registrationModule.openFlag('${id}')">🚩</button>
          <button class="btn-danger btn-small" onclick="registrationModule.openDelete('${id}')">حذف</button>
        </div>
      `;
      cardsList.appendChild(card);
    });
  }

  /**
   * Handle form submission
   */
  async handleSubmit(formData) {
    // Validate
    const validation = Validators.validateRegistrationForm(formData);
    if (!validation.valid) {
      Object.entries(validation.errors).forEach(([field, message]) => {
        Validators.showFieldError('f' + field.charAt(0).toUpperCase() + field.slice(1), message);
      });
      toast.error('يرجى تصحيح الأخطاء في الحقول');
      return;
    }

    const entry = {
      name: formData.name,
      lastName: formData.lastName,
      birth: formData.birth,
      electoralNum: formData.electoralNum || null,
      phone: formData.phone || null,
      educationLevel: formData.educationLevel,
      notes: formData.notes || null,
      assignLevel: null,
      center: null,
      centerPosition: null,
      officeNumber: null,
      officeType: null,
      officePosition: null,
      flagged: false,
      issueType: null,
      issueReason: null
    };

    const btn = document.getElementById('btnSubmit');
    btn.disabled = true;
    btn.textContent = 'جارٍ الحفظ...';

    try {
      await firebaseService.addEntry(entry);
      toast.success('تم تسجيل المؤطر بنجاح ✅');
      document.getElementById('frmMoatir').reset();
      Validators.clearFieldErrors('frmMoatir');
    } catch (err) {
      toast.error('حدث خطأ أثناء الحفظ: ' + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = 'حفظ المؤطر';
    }
  }

  /**
   * Open edit modal
   */
  openEdit(id) {
    const e = this.allEntries[id];
    if (!e) return;
    this.currentEditId = id;
    modal.showEditModal(e, (data) => this._saveEdit(data));
  }

  /**
   * Save edit
   */
  async _saveEdit(data) {
    if (!this.currentEditId) return;

    const validation = Validators.validateRegistrationForm(data);
    if (!validation.valid) {
      toast.error('يرجى تصحيح البيانات');
      return;
    }

    try {
      await firebaseService.updateEntry(this.currentEditId, data);
      modal.close();
      toast.success('تم تعديل البيانات بنجاح ✅');
      this.currentEditId = null;
    } catch (err) {
      toast.error('خطأ أثناء التعديل: ' + err.message);
    }
  }

  /**
   * Open flag modal
   */
  openFlag(id) {
    const e = this.allEntries[id];
    if (!e) return;
    this.currentFlagId = id;
    const name = `${e.name} ${e.lastName}`;
    modal.showFlagModal(
      name,
      e.issueType || '',
      (issueType) => this._saveFlag(issueType),
      () => this._removeFlag()
    );
  }

  /**
   * Save flag
   */
  async _saveFlag(issueType) {
    if (!this.currentFlagId) return;
    try {
      await firebaseService.updateEntry(this.currentFlagId, {
        flagged: true,
        issueType,
        issueReason: null
      });
      modal.close();
      toast.warning('تم وضع إشارة على المؤطر 🚩');
      this.currentFlagId = null;
    } catch (err) {
      toast.error('خطأ: ' + err.message);
    }
  }

  /**
   * Remove flag
   */
  async _removeFlag() {
    if (!this.currentFlagId) return;
    try {
      await firebaseService.updateEntry(this.currentFlagId, {
        flagged: false,
        issueType: null,
        issueReason: null
      });
      modal.close();
      toast.info('تم إزالة الإشارة');
      this.currentFlagId = null;
    } catch (err) {
      toast.error('خطأ: ' + err.message);
    }
  }

  /**
   * Open delete confirmation
   */
  openDelete(id) {
    this.currentDeleteId = id;
    modal.showDeleteModal(() => this._confirmDelete());
  }

  /**
   * Confirm delete
   */
  async _confirmDelete() {
    if (!this.currentDeleteId) return;
    try {
      await firebaseService.deleteEntry(this.currentDeleteId);
      modal.close();
      toast.success('تم حذف المؤطر');
      this.currentDeleteId = null;
    } catch (err) {
      toast.error('خطأ أثناء الحذف: ' + err.message);
    }
  }

  /**
   * Set up event listeners
   */
  _setupEventListeners() {
    // Form submission
    const form = document.getElementById('frmMoatir');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleSubmit({
          name: document.getElementById('fName').value.trim(),
          lastName: document.getElementById('fLastName').value.trim(),
          birth: document.getElementById('fBirth').value,
          electoralNum: document.getElementById('fElectoralNum').value.trim(),
          phone: document.getElementById('fPhone').value.trim(),
          educationLevel: document.getElementById('fEducation').value,
          notes: document.getElementById('fNotes').value.trim()
        });
      });
    }

    // Reset button
    const resetBtn = document.getElementById('btnReset');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        form?.reset();
        Validators.clearFieldErrors('frmMoatir');
      });
    }

    // Edit modal save
    const btnSaveEdit = document.getElementById('btnSaveEdit');
    if (btnSaveEdit) {
      btnSaveEdit.addEventListener('click', () => modal.confirmEdit());
    }

    // Edit modal cancel
    const btnCancelEdit = document.getElementById('btnCancelEdit');
    if (btnCancelEdit) {
      btnCancelEdit.addEventListener('click', () => {
        modal.close();
        this.currentEditId = null;
      });
    }

    // Flag modal save
    const btnSaveFlag = document.getElementById('btnSaveFlag');
    if (btnSaveFlag) {
      btnSaveFlag.addEventListener('click', () => modal.confirmFlag());
    }

    // Flag modal remove
    const btnRemoveFlag = document.getElementById('btnRemoveFlag');
    if (btnRemoveFlag) {
      btnRemoveFlag.addEventListener('click', () => modal.confirmRemoveFlag());
    }

    // Flag modal cancel
    const btnCancelFlag = document.getElementById('btnCancelFlag');
    if (btnCancelFlag) {
      btnCancelFlag.addEventListener('click', () => {
        modal.close();
        this.currentFlagId = null;
      });
    }

    // Delete modal confirm
    const btnConfirmDelete = document.getElementById('btnConfirmDelete');
    if (btnConfirmDelete) {
      btnConfirmDelete.addEventListener('click', () => modal.confirmDelete());
    }

    // Delete modal cancel
    const btnCancelDelete = document.getElementById('btnCancelDelete');
    if (btnCancelDelete) {
      btnCancelDelete.addEventListener('click', () => {
        modal.close();
        this.currentDeleteId = null;
      });
    }
  }

  /**
   * Set up search
   */
  _setupSearch() {
    searchComponent.setup(Object.values(this.allEntries), (results) => {
      this.renderTable(results);
    });
  }

  /**
   * Helper: Get entry ID from object
   */
  _getEntryId(entry) {
    const entries = this.allEntries;
    if (!entries) return '';
    for (const [id, e] of Object.entries(entries)) {
      if (e === entry) return id;
    }
    return '';
  }

  /**
   * Helper: Get distribution text
   */
  _getDistributionText(entry) {
    if (entry.assignLevel === 'office' && entry.center) {
      return `${Helpers.centerLabel(entry.center)} - مكتب ${entry.officeNumber} (${entry.officeType})`;
    } else if (entry.assignLevel === 'center' && entry.center) {
      return `${Helpers.centerLabel(entry.center)} - طاقم المركز`;
    }
    return '<span style="color:var(--muted);">غير موزّع</span>';
  }

  /**
   * Helper: Get position badge HTML
   */
  _getPositionBadge(position, color) {
    if (position) {
      return `<span class="pos-badge" style="background:${color}22; color:${color}; border:1px solid ${color}55;">${Helpers.escapeHtml(position)}</span>`;
    }
    return '<span style="color:var(--muted); font-size:12px;">بدون توزيع</span>';
  }

  /**
   * Helper: Get flag note HTML
   */
  _getFlagNote(entry) {
    if (entry.flagged) {
      return `<span class="flag-note">🚩 ${Helpers.escapeHtml(entry.issueType || 'مشكلة')}</span>`;
    }
    return '';
  }
}

// Export singleton
const registrationModule = new RegistrationModule();
