/* ============================================================
   ANIE Platform - Toast Notification Component
   ============================================================ */

class Toast {
  constructor() {
    this.container = null;
    this.init();
  }

  init() {
    // Create toast container if not exists
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toastContainer';
      this.container.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 8px;
        pointer-events: none;
        max-width: 400px;
        width: 90%;
      `;
      document.body.appendChild(this.container);
    }
  }

  /**
   * Show a toast notification
   * @param {string} message - The message to display
   * @param {string} type - 'success', 'error', 'warning', 'info'
   * @param {number} duration - Duration in ms (default: 3000)
   */
  show(message, type = 'info', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.style.cssText = `
      pointer-events: auto;
      padding: 14px 18px;
      border-radius: 12px;
      font-family: 'Cairo', sans-serif;
      font-size: 13px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.3);
      animation: toastIn 0.3s ease forwards;
      direction: rtl;
    `;

    // Set colors based on type
    const colors = {
      success: {
        bg: 'rgba(34, 197, 94, 0.15)',
        border: 'rgba(34, 197, 94, 0.3)',
        color: '#7de7a3',
        icon: '✅'
      },
      error: {
        bg: 'rgba(239, 68, 68, 0.15)',
        border: 'rgba(239, 68, 68, 0.3)',
        color: '#ff9c9c',
        icon: '❌'
      },
      warning: {
        bg: 'rgba(245, 158, 11, 0.15)',
        border: 'rgba(245, 158, 11, 0.3)',
        color: '#f5c264',
        icon: '⚠️'
      },
      info: {
        bg: 'rgba(61, 139, 255, 0.15)',
        border: 'rgba(61, 139, 255, 0.3)',
        color: '#8fbcff',
        icon: 'ℹ️'
      }
    };

    const config = colors[type] || colors.info;

    toast.style.background = config.bg;
    toast.style.border = `1px solid ${config.border}`;
    toast.style.color = config.color;

    toast.innerHTML = `
      <span>${config.icon}</span>
      <span style="flex:1;">${message}</span>
      <button onclick="this.parentElement.remove()" style="
        background: none;
        border: none;
        color: inherit;
        cursor: pointer;
        padding: 0;
        font-size: 16px;
        opacity: 0.7;
        font-family: 'Cairo', sans-serif;
      ">✕</button>
    `;

    this.container.appendChild(toast);

    // Auto remove after duration
    if (duration > 0) {
      setTimeout(() => {
        if (toast.parentElement) {
          toast.classList.add('removing');
          setTimeout(() => {
            if (toast.parentElement) {
              toast.remove();
            }
          }, 300);
        }
      }, duration);
    }

    return toast;
  }

  /**
   * Show success toast
   */
  success(message, duration) {
    return this.show(message, 'success', duration);
  }

  /**
   * Show error toast
   */
  error(message, duration) {
    return this.show(message, 'error', duration);
  }

  /**
   * Show warning toast
   */
  warning(message, duration) {
    return this.show(message, 'warning', duration);
  }

  /**
   * Show info toast
   */
  info(message, duration) {
    return this.show(message, 'info', duration);
  }

  /**
   * Remove all toasts
   */
  clear() {
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
}

// Export singleton
const toast = new Toast();
