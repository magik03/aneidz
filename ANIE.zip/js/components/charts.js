/* ============================================================
   ANIE Platform - Charts Module (Using Chart.js)
   ============================================================ */

class ChartsManager {
  constructor() {
    this.charts = {};
    this.colors = {
      primary: '#3d8bff',
      success: '#22c55e',
      danger: '#ef4444',
      warning: '#f59e0b',
      purple: '#a78bfa',
      cyan: '#22d3ee',
      orange: '#f97316',
      pink: '#ec4899'
    };
  }

  /**
   * Initialize Chart.js if not loaded
   */
  async init() {
    if (typeof Chart === 'undefined') {
      await this._loadScript('https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js');
    }
  }

  /**
   * Create education level pie chart
   */
  createEducationChart(canvasId, entries) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    // Destroy existing chart
    this._destroyChart(canvasId);

    const educationCounts = {};
    CONFIG.EDUCATION_LEVELS.forEach(level => {
      educationCounts[level] = 0;
    });

    Object.values(entries).forEach(e => {
      if (educationCounts.hasOwnProperty(e.educationLevel)) {
        educationCounts[e.educationLevel]++;
      }
    });

    const labels = Object.keys(educationCounts).filter(k => educationCounts[k] > 0);
    const data = labels.map(l => educationCounts[l]);
    const backgroundColors = [
      '#3d8bff', '#22c55e', '#f59e0b', '#ef4444',
      '#a78bfa', '#22d3ee', '#f97316'
    ];

    this.charts[canvasId] = new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: backgroundColors.slice(0, labels.length),
          borderColor: '#1a2436',
          borderWidth: 3,
          hoverOffset: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'bottom',
            rtl: true,
            labels: {
              font: {
                family: 'Cairo',
                size: 12
              },
              color: '#e7edf7',
              padding: 12,
              usePointStyle: true
            }
          },
          tooltip: {
            rtl: true,
            titleFont: { family: 'Cairo' },
            bodyFont: { family: 'Cairo' },
            callbacks: {
              label: function(context) {
                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                const value = context.raw;
                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                return `${context.label}: ${value} مؤطر (${percentage}%)`;
              }
            }
          }
        },
        cutout: '65%',
        animation: {
          animateRotate: true,
          duration: 1000
        }
      }
    });
  }

  /**
   * Create center occupancy bar chart
   */
  createCenterChart(canvasId, entries) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    this._destroyChart(canvasId);

    const centerCodes = Object.keys(CONFIG.CENTERS);
    const labels = centerCodes.map(c => CONFIG.CENTERS[c].name);
    
    // Count total seats per center
    const totalSeats = centerCodes.map(code => {
      const center = CONFIG.CENTERS[code];
      return CONFIG.CENTER_POSITIONS.length + (center.offices.length * CONFIG.OFFICE_TYPES.length * CONFIG.POSITIONS_ORDER.length);
    });

    // Count filled seats per center
    const filledSeats = centerCodes.map(code => {
      let count = 0;
      Object.values(entries).forEach(e => {
        if (e.center === code && e.assignLevel) count++;
      });
      return count;
    });

    const emptySeats = totalSeats.map((total, i) => total - filledSeats[i]);

    this.charts[canvasId] = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'مشغول',
            data: filledSeats,
            backgroundColor: 'rgba(34, 197, 94, 0.7)',
            borderColor: '#22c55e',
            borderWidth: 1,
            borderRadius: 4
          },
          {
            label: 'شاغر',
            data: emptySeats,
            backgroundColor: 'rgba(142, 160, 189, 0.3)',
            borderColor: '#8ea0bd',
            borderWidth: 1,
            borderRadius: 4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        indexAxis: 'y',
        plugins: {
          legend: {
            position: 'top',
            rtl: true,
            labels: {
              font: { family: 'Cairo', size: 12 },
              color: '#e7edf7',
              usePointStyle: true
            }
          },
          tooltip: {
            rtl: true,
            titleFont: { family: 'Cairo' },
            bodyFont: { family: 'Cairo' }
          }
        },
        scales: {
          x: {
            stacked: true,
            ticks: {
              font: { family: 'Cairo' },
              color: '#8ea0bd'
            },
            grid: { color: 'rgba(43, 58, 84, 0.3)' }
          },
          y: {
            stacked: true,
            ticks: {
              font: { family: 'Cairo', size: 11 },
              color: '#e7edf7'
            },
            grid: { display: false }
          }
        },
        animation: {
          duration: 1000
        }
      }
    });
  }

  /**
   * Create registration timeline (line chart)
   */
  createTimelineChart(canvasId, entries) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    this._destroyChart(canvasId);

    // Group by date
    const dateGroups = {};
    Object.values(entries).forEach(e => {
      if (!e.createdAt) return;
      const date = new Date(e.createdAt).toLocaleDateString('ar-DZ');
      dateGroups[date] = (dateGroups[date] || 0) + 1;
    });

    const labels = Object.keys(dateGroups).sort((a, b) => {
      const partsA = a.split('/');
      const partsB = b.split('/');
      return new Date(partsA[2], partsA[1] - 1, partsA[0]) - 
             new Date(partsB[2], partsB[1] - 1, partsB[0]);
    });
    const data = labels.map(l => dateGroups[l]);

    // Cumulative data
    let cumulative = 0;
    const cumulativeData = data.map(v => {
      cumulative += v;
      return cumulative;
    });

    this.charts[canvasId] = new Chart(canvas, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'التسجيلات اليومية',
            data,
            borderColor: '#3d8bff',
            backgroundColor: 'rgba(61, 139, 255, 0.1)',
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#3d8bff',
            pointRadius: 4,
            pointHoverRadius: 6
          },
          {
            label: 'المجموع التراكمي',
            data: cumulativeData,
            borderColor: '#22c55e',
            backgroundColor: 'rgba(34, 197, 94, 0.05)',
            fill: true,
            tension: 0.4,
            borderDash: [5, 5],
            pointBackgroundColor: '#22c55e',
            pointRadius: 3,
            pointHoverRadius: 5
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'top',
            rtl: true,
            labels: {
              font: { family: 'Cairo', size: 12 },
              color: '#e7edf7',
              usePointStyle: true
            }
          },
          tooltip: {
            rtl: true,
            titleFont: { family: 'Cairo' },
            bodyFont: { family: 'Cairo' }
          }
        },
        scales: {
          x: {
            ticks: {
              font: { family: 'Cairo', size: 10 },
              color: '#8ea0bd',
              maxRotation: 45
            },
            grid: { color: 'rgba(43, 58, 84, 0.3)' }
          },
          y: {
            beginAtZero: true,
            ticks: {
              font: { family: 'Cairo' },
              color: '#8ea0bd',
              stepSize: 1
            },
            grid: { color: 'rgba(43, 58, 84, 0.3)' }
          }
        },
        animation: {
          duration: 1200
        },
        interaction: {
          intersect: false,
          mode: 'index'
        }
      }
    });
  }

  /**
   * Create summary stats cards
   */
  createStatsSummary(entries) {
    const total = Object.keys(entries).length;
    const assigned = Object.values(entries).filter(e => e.assignLevel).length;
    const flagged = Object.values(entries).filter(e => e.flagged).length;
    
    // Count total seats
    let totalSeats = 0;
    Object.keys(CONFIG.CENTERS).forEach(code => {
      const center = CONFIG.CENTERS[code];
      totalSeats += CONFIG.CENTER_POSITIONS.length;
      totalSeats += center.offices.length * CONFIG.OFFICE_TYPES.length * CONFIG.POSITIONS_ORDER.length;
    });

    const emptySeats = totalSeats - assigned;

    this._animateCounter('statTotal', total);
    this._animateCounter('statAssigned', assigned);
    this._animateCounter('statEmpty', emptySeats);
    this._animateCounter('statFlagged', flagged);
  }

  /**
   * Animate counter
   */
  _animateCounter(elementId, target) {
    const el = document.getElementById(elementId);
    if (!el) return;

    const current = parseInt(el.textContent) || 0;
    const duration = 1000;
    const startTime = performance.now();

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = Math.floor(current + (target - current) * eased);
      
      el.textContent = value.toLocaleString('ar-DZ');
      el.classList.add('count-animate');

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        el.textContent = target.toLocaleString('ar-DZ');
      }
    };

    requestAnimationFrame(animate);
  }

  /**
   * Destroy a chart
   */
  _destroyChart(id) {
    if (this.charts[id]) {
      this.charts[id].destroy();
      delete this.charts[id];
    }
  }

  /**
   * Destroy all charts
   */
  destroyAll() {
    Object.keys(this.charts).forEach(id => this._destroyChart(id));
  }

  /**
   * Load external script
   */
  _loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }
}

// Export singleton
const chartsManager = new ChartsManager();
