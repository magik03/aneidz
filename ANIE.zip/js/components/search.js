/* ============================================================
   ANIE Platform - Advanced Search Component
   ============================================================ */

class SearchComponent {
  constructor() {
    this.searchTerm = '';
    this.filters = {};
    this.onSearchCallback = null;
    this.debouncedSearch = Helpers.debounce(this._performSearch.bind(this), 300);
  }

  /**
   * Initialize search with Fuse.js
   */
  async init() {
    if (typeof Fuse === 'undefined') {
      await this._loadScript('https://cdnjs.cloudflare.com/ajax/libs/fuse.js/7.0.0/fuse.min.js');
    }
  }

  /**
   * Set up search on entries
   * @param {Array} entries - Array of entry objects
   * @param {Function} callback - Callback with filtered results
   */
  setup(entries, callback) {
    this.allEntries = entries;
    this.onSearchCallback = callback;
    
    this.fuse = new Fuse(entries, {
      keys: [
        { name: 'name', weight: 0.3 },
        { name: 'lastName', weight: 0.3 },
        { name: 'electoralNum', weight: 0.15 },
        { name: 'phone', weight: 0.1 },
        { name: 'notes', weight: 0.05 },
        { name: 'centerPosition', weight: 0.05 },
        { name: 'officePosition', weight: 0.05 }
      ],
      threshold: 0.3,
      distance: 100,
      minMatchCharLength: 1,
      shouldSort: true,
      includeScore: true,
      findAllMatches: false
    });

    this._setupEventListeners();
  }

  /**
   * Set up event listeners for search and filter inputs
   */
  _setupEventListeners() {
    const searchBox = document.getElementById('searchBox');
    if (searchBox) {
      searchBox.addEventListener('input', (e) => {
        this.searchTerm = e.target.value.trim();
        this.debouncedSearch();
      });
    }

    const filterPosition = document.getElementById('filterPosition');
    if (filterPosition) {
      filterPosition.addEventListener('change', (e) => {
        this.filters.position = e.target.value;
        this._performSearch();
      });
    }

    const filterFlagged = document.getElementById('filterFlaggedOnly');
    if (filterFlagged) {
      filterFlagged.addEventListener('change', (e) => {
        this.filters.flaggedOnly = e.target.checked;
        this._performSearch();
      });
    }

    // Monitor filters
    const monCenter = document.getElementById('monFilterCenter');
    if (monCenter) {
      monCenter.addEventListener('change', (e) => {
        this.filters.monCenter = e.target.value;
        if (this.onMonitorSearchCallback) {
          this.onMonitorSearchCallback(this.filters);
        }
      });
    }

    const monStatus = document.getElementById('monFilterStatus');
    if (monStatus) {
      monStatus.addEventListener('change', (e) => {
        this.filters.monStatus = e.target.value;
        if (this.onMonitorSearchCallback) {
          this.onMonitorSearchCallback(this.filters);
        }
      });
    }

    // Quick filter buttons
    document.querySelectorAll('[data-quick-filter]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const filter = e.currentTarget.dataset.quickFilter;
        this.searchTerm = filter;
        if (searchBox) searchBox.value = filter;
        this._performSearch();
      });
    });
  }

  /**
   * Perform search with current filters
   */
  _performSearch() {
    if (!this.onSearchCallback) return;

    let results = [];
    
    if (this.searchTerm) {
      // Use Fuse.js for fuzzy search
      const fuseResults = this.fuse.search(this.searchTerm);
      results = fuseResults.map(r => r.item);
    } else {
      results = [...this.allEntries];
    }

    // Apply filters
    if (this.filters.position) {
      results = results.filter(e => {
        const pos = Helpers.getEntryPosition(e);
        return pos === this.filters.position;
      });
    }

    if (this.filters.flaggedOnly) {
      results = results.filter(e => e.flagged);
    }

    this.onSearchCallback(results);
  }

  /**
   * Set monitor search callback
   */
  onMonitorSearch(callback) {
    this.onMonitorSearchCallback = callback;
  }

  /**
   * Update entries data
   */
  updateEntries(entries) {
    this.allEntries = entries;
    if (this.fuse) {
      this.fuse.setCollection(entries);
    }
    this._performSearch();
  }

  /**
   * Clear search and filters
   */
  clear() {
    this.searchTerm = '';
    this.filters = {};
    
    const searchBox = document.getElementById('searchBox');
    if (searchBox) searchBox.value = '';
    
    const filterPosition = document.getElementById('filterPosition');
    if (filterPosition) filterPosition.value = '';
    
    const filterFlagged = document.getElementById('filterFlaggedOnly');
    if (filterFlagged) filterFlagged.checked = false;
    
    this._performSearch();
  }

  /**
   * Load external script
   */
  _loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }
}

// Export singleton
const searchComponent = new SearchComponent();
