/* ============================================================
   ANIE Platform - Modal Component
   ============================================================ */

class Modal {
  constructor() {
    this.currentModal = null;
    this.callbacks = {};
  }

  /**
   * Show a modal
   * @param {string} modalId - The modal element ID
   */
  show(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    modal.classList.add('show');
    this.currentModal = modal;

    // Prevent body scroll
    document.body.style.overflow = 'hidden';
  }

  /**
   * Close current modal
   */
  close() {
    if (this.currentModal) {
      this.currentModal.classList.remove('show');
      document.body.style.overflow = '';
      this.currentModal = null;
    }
  }

  /**
   * Close all modals
   */
  closeAll() {
    document.querySelectorAll('.modal-overlay.show').forEach(modal => {
      modal.classList.remove('show');
    });
    document.body.style.overflow = '';
    this.currentModal = null;
  }

  /**
   * Show edit modal with data
   * @param {Object} data - Entry data
   * @param {Function} onSave - Callback on save
   */
  showEditModal(data, onSave) {
    this.callbacks.editSave = onSave;

    document.getElementById('eName').value = data.name || '';
    document.getElementById('eLastName').value = data.lastName || '';
    document.getElementById('eBirth').value = data.birth || '';
    document.getElementById('eElectoralNum').value = data.electoralNum || '';
    document.getElementById('ePhone').value = data.phone || '';
    document.getElementById('eEducation').value = data.educationLevel || 'بدون مستوى';
    document.getElementById('eNotes').value = data.notes || '';

    this.show('editModal');
  }

  /**
   * Show flag modal
   * @param {string} name - Moatir name
   * @param {string} issueType - Current issue type
   * @param {Function} onSave - Callback on save
   * @param {Function} onRemove - Callback on remove flag
   */
  showFlagModal(name, issueType, onSave, onRemove) {
    this.callbacks.flagSave = onSave;
    this.callbacks.flagRemove = onRemove;

    document.getElementById('flagMoatirName').textContent = name;
    document.getElementById('flagIssueType').value = issueType || '';

    this.show('flagModal');
  }

  /**
   * Show delete confirmation modal
   * @param {Function} onConfirm - Callback on confirm
   */
  showDeleteModal(onConfirm) {
    this.callbacks.deleteConfirm = onConfirm;
    this.show('deleteModal');
  }

  /**
   * Confirm edit save
   */
  confirmEdit() {
    if (this.callbacks.editSave) {
      const data = {
        name: document.getElementById('eName').value.trim(),
        lastName: document.getElementById('eLastName').value.trim(),
        birth: document.getElementById('eBirth').value,
        electoralNum: document.getElementById('eElectoralNum').value.trim() || null,
        phone: document.getElementById('ePhone').value.trim() || null,
        educationLevel: document.getElementById('eEducation').value,
        notes: document.getElementById('eNotes').value.trim() || null
      };
      this.callbacks.editSave(data);
    }
  }

  /**
   * Confirm flag save
   */
  confirmFlag() {
    if (this.callbacks.flagSave) {
      const issueType = document.getElementById('flagIssueType').value.trim();
      if (issueType) {
        this.callbacks.flagSave(issueType);
      }
    }
  }

  /**
   * Confirm flag removal
   */
  confirmRemoveFlag() {
    if (this.callbacks.flagRemove) {
      this.callbacks.flagRemove();
    }
  }

  /**
   * Confirm delete
   */
  confirmDelete() {
    if (this.callbacks.deleteConfirm) {
      this.callbacks.deleteConfirm();
    }
  }
}

// Export singleton
const modal = new Modal();
